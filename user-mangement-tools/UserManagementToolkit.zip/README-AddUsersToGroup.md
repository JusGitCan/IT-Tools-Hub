# Add Users To Group

Mass-adds **existing** users to one or more Entra ID groups. Built for the
case where a group got missed during a bulk new-hire import and you don't
want to touch each account by hand.

## What it does
- Add users one at a time, paste a list of UPNs/emails, or type directly
  into the grid.
- Enter one or more group names (comma-separated) and click **Add to
  group(s)** to add every checked row to all of them.
- Correctly routes M365/security groups through Microsoft Graph and only
  true mail-enabled distribution lists through Exchange Online (fixed
  misclassification bug from the main wizard's group-add logic).

## What it never does
- Never creates, disables, licenses, or otherwise modifies a user account.
- If a user or group can't be found, that row is noted in Status and the
  rest of the batch keeps going — one bad row doesn't stop the run.

## How to run it
Always launch via **Launch-AddUsersToGroup.bat**, never by double-clicking
or right-clicking the `.ps1` directly. The `.bat` forces Windows PowerShell
into STA mode, which the sign-in UI requires — running the `.ps1` on its
own can throw a "single-threaded apartment" error.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in (and Exchange Online sign-in, only if
a true distribution list is targeted) using your own admin credentials.

## Results
A per-run results CSV and PowerShell transcript are saved next to the
script after each run.

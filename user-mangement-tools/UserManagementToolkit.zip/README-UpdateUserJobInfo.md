# Update User Job Info

Mass-updates Job Title and/or Employee ID on **existing** users — e.g.
after a reorg, a department rename, a batch of title corrections from
HR, or a contractor converting to full-time and getting issued a new
Employee ID.

## What it does
- Job Title and Employee ID are updated **independently per row** — a
  row can change one, the other, or both. Leaving a field blank for a
  row leaves that field untouched on that user.
- **Employee ID mirroring:** CorroHealth also stores a copy of the
  Employee ID in the "Preferred data location" field. Whenever a row
  sets a new Employee ID, this tool automatically writes the same value
  to Preferred data location too — one entry, two fields, always in
  sync.
- Three ways to enter data, usable together in the same run:
  - **Manual** — type directly into the grid.
  - **Paste list** — `UPN, New Title, New Employee ID` per line (leave a
    field blank between commas to skip it, e.g. `user@corp.com,,CW123456`
    to update only the Employee ID).
  - **Upload CSV** — matches a UPN column plus a Job Title and/or
    Employee ID column by header text. Recognizes several common header
    spellings, including `UserEmail`/`EID`/`Designation` (CorroHealth's
    HR export format) alongside standard ones.
- **Bulk-apply panel** — stamp one title and/or one Employee ID onto
  every checked row at once.
- Click **Update user info** to run.

## What it never does
- Never creates, disables, licenses, or otherwise modifies a user account
  — only Job Title, Employee ID, and (as a mirror of Employee ID)
  Preferred Data Location are touched.
- If a user can't be found or an update fails, that row is noted in
  Status and the rest of the batch keeps going.

## How to run it
Always launch via **Launch-UpdateUserJobInfo.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat` forces
Windows PowerShell into STA mode.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in only (`User.ReadWrite.All`) — no
Exchange Online connection is made, since Job Title, Employee ID, and
Preferred Data Location are all Graph-only properties.

## Results
A per-run results CSV and PowerShell transcript are saved next to the
script after each run, plus a "Re-export last results" button as backup.

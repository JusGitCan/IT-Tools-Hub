# Reset User Passwords

Gives **existing** users each a new, non-identical password — for fixing a
batch that was accidentally created with a single shared password.

## What it does
- Add users one at a time, paste a list of UPNs/emails, or type directly
  into the grid.
- Two password modes:
  - **Auto-generate a unique 16-character password per user** (recommended)
  - **Prefix + random 5-digit suffix per user** (e.g. `CorroHealth@@34961`)
    — each user still gets a different password, just in a predictable
    format if that's preferred for a handoff sheet.
- Click **Reset passwords** to reset every checked row.

## What it never does
- Never creates, disables, licenses, or otherwise modifies a user account
  — only the password is touched.
- Deliberately does **not** offer a "one shared password for everyone"
  option. That's the exact mistake this tool exists to fix, so it isn't
  offered here even as a convenience.
- If a user can't be found or a reset fails, that row is noted in Status
  and the rest of the batch keeps going.

## How to run it
Always launch via **Launch-ResetUserPasswords.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat` forces
Windows PowerShell into STA mode, which the sign-in UI requires.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in using your own admin credentials.

## Results
A per-run results CSV (including the new passwords — handle it like any
credential export) and PowerShell transcript are saved next to the script
after each run.

# Invite External Guests

Retroactively invites **existing** home-tenant users as B2B guests into the
external tenant — for batches created on an older version of the wizard
before the external-invite step existed, or when an invite failed and
needs a clean retry without re-running the whole user-creation import.

## What it does
- Add users one at a time, paste a list of UPNs/emails, or type directly
  into the grid — First name / Last name / Job title (optional) can be
  filled in per row.
- Click **Send invites** to invite every checked row into the external
  tenant, exactly like the main wizard's own external-invite step: same
  UPN as the invited email, no invite email sent, name/title copied over,
  no groups or roles assigned.

## What it never does
- Never creates, disables, or otherwise modifies the **home-tenant**
  account. It only sends the external invite.
- If a user can't be found or an invite fails, that row is noted in
  Status and the rest of the batch keeps going.

## How to run it
Always launch via **Launch-InviteExternalGuests.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat` forces
Windows PowerShell into STA mode, which the sign-in UI requires.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in using your own admin credentials, with
access to the external tenant (`10096675-b04b-4d53-88e6-9c640623b9ea`).
A tenant-context check runs before any invites are sent, to catch a silent
wrong-tenant sign-in before it causes a no-op run.

## Results
A per-run results CSV and PowerShell transcript are saved next to the
script after each run.

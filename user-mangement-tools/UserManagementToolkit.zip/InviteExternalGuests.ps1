#Requires -Version 5.1
<#
    CorroHealth - Invite External Guests
    =====================================
    A small standalone WinForms tool for a one-off, mass "invite these
    already-existing home-tenant users as B2B guests into the external
    tenant" action - e.g. when a batch was created on an older version of
    the wizard before the external-invite step existed, or an external
    invite failed and needs a clean retry, without re-running the whole
    user-creation import.

    This tool NEVER creates, disables, or otherwise modifies a HOME TENANT
    user account. It only invites existing home-tenant users into the
    external tenant, exactly like the wizard's own "Invite external user
    (Preview)" step: same UPN as the invited email, no invite email sent,
    first/last name and job title copied over, no groups or roles assigned.

    Companion to UserProvisioningWizard.ps1 and AddUsersToGroup.ps1 - same
    look and feel, same Corro brand palette.
#>

# ============================================================
#  STA self-guard (same reasoning as the other tools)
# ============================================================
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne [System.Threading.ApartmentState]::STA) {
    $scriptPath = $MyInvocation.MyCommand.Path
    if (-not $scriptPath) { $scriptPath = $PSCommandPath }
    if (-not $scriptPath) { $scriptPath = $MyInvocation.MyCommand.Definition }

    if ($scriptPath -and (Test-Path $scriptPath)) {
        Start-Process -FilePath "powershell.exe" `
            -ArgumentList @("-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", "`"$scriptPath`"")
        exit
    } else {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "This tool must run in STA mode, but it was started in MTA and could not relaunch itself automatically.`n`nPlease launch it using Launch-InviteExternalGuests.bat instead.",
            "Please use the .bat launcher", "OK", "Warning") | Out-Null
        exit
    }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ============================================================
#  Corro brand palette + theme helpers (matches the other tools)
# ============================================================
$corroPurple    = [System.Drawing.Color]::FromArgb(0x51, 0x2e, 0x6e)
$corroSecondary = [System.Drawing.Color]::FromArgb(0x5e, 0x17, 0x4d)
$corroAccent    = [System.Drawing.Color]::FromArgb(0xe7, 0xb5, 0x24)
$themeBg        = [System.Drawing.Color]::White
$themePanel     = [System.Drawing.Color]::FromArgb(240, 240, 240)
$themeControl   = [System.Drawing.Color]::White
$themeText      = [System.Drawing.Color]::FromArgb(30, 30, 30)
$themeTextMuted = [System.Drawing.Color]::FromArgb(130, 130, 130)
$themeHeaderTxt = [System.Drawing.Color]::FromArgb(0x50, 0x2e, 0x6d)
$themeRowAlt    = [System.Drawing.Color]::FromArgb(246, 243, 249)

function Set-DarkButton {
    param($Button, [switch]$Accent)
    $Button.FlatStyle = "Flat"
    if ($Accent) { $Button.ForeColor = $corroPurple; $Button.BackColor = $corroAccent }
    else { $Button.ForeColor = $corroPurple; $Button.BackColor = [System.Drawing.Color]::FromArgb(248, 246, 250) }
    $Button.FlatAppearance.BorderColor = $corroSecondary
    $Button.FlatAppearance.BorderSize = 1
    $Button.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(230, 222, 240)
}
function Set-DarkForm { param($FormObj) $FormObj.BackColor = $themeBg; $FormObj.ForeColor = $themeText }

# ============================================================
#  External tenant target - same tenant + redirect URL the main wizard uses
# ============================================================
$externalTenantId          = "10096675-b04b-4d53-88e6-9c640623b9ea"
$externalInviteRedirectUrl = "https://myapplications.microsoft.com/"

# ============================================================
#  Connect - directly to the EXTERNAL tenant. Invitations are created in
#  the target tenant, not the home tenant, and this tool never touches
#  home-tenant user objects, so there's no need to sign into home first.
# ============================================================
Write-Host "Connecting to the external tenant..." -ForegroundColor Cyan
try {
    Connect-MgGraph -TenantId $externalTenantId -Scopes "User.Invite.All", "User.ReadWrite.All" -NoWelcome -ErrorAction Stop
    $actualTenantId = (Get-MgContext).TenantId
    if ($actualTenantId -ne $externalTenantId) {
        throw "Connected, but the active Graph context is tenant '$actualTenantId', not the expected external tenant '$externalTenantId'. This usually means a cached sign-in session was reused instead of switching tenants. Try closing this tool and any other open PowerShell/Graph session, then relaunch."
    }
} catch {
    [System.Windows.Forms.MessageBox]::Show("Could not connect to the external tenant:`n`n$($_.Exception.Message)", "External tenant sign-in failed", "OK", "Error") | Out-Null
    exit
}

$scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$sessionTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$transcriptPath = Join-Path $scriptDir "InviteExternalGuests_$sessionTimestamp.txt"
Start-Transcript -Path $transcriptPath | Out-Null

# ============================================================
#  Main form + brand header
# ============================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "CorroHealth - Invite External Guests"
$form.Size = New-Object System.Drawing.Size(860, 640)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = New-Object System.Drawing.Size(700, 520)
Set-DarkForm $form

$brandBar = New-Object System.Windows.Forms.Panel
$brandBar.Dock = "Top"; $brandBar.Height = 44; $brandBar.BackColor = $corroPurple

$logoB64 = "iVBORw0KGgoAAAANSUhEUgAAACIAAAAeCAYAAABJ/8wUAAAKMklEQVR4nK1XfZRVVRXf+5z77r3vY750BPygBksNZiQVrDBzGNOWkWXgeq9cajCgKIiNGqt0Yd15pIIlmWLmjNaklth9EGWIJup7RJbWgIozIJgaaYoCM8x7736ej90fwygGflV3rbPWXWd/nN/Z5+yzfxvgf/iy5PKRfwSApQMDdde/uHN0kcjeX89xiL2fL/wvMaDjOJjP5/UNfX/++B5ptQ8p3jok+FgRassI4iFbyK0pKVd/1a7cP23atCjruryQy6n/HxACdDqHQSx++tFFFbCuCe36tM9T4GkbRKCA+xFg1QcsV4FVqpszQsztvuTsp94LzIcG4pLLc5hT39/4QBdlGuYORRz8kIKYkus0mL1cYegNeaMhiM6UkZoIgYBEEAYZimd0Lzj34WzW5YXCgWA+FBDXdXkul1PLNv3mGqqtvWGwCqDAesJiqfn5iZM2769LRMaclRvaq3uryyiUNdwPyoen7Uk3X/aVF53OTszn83p/feODgnDIYTnMqds3rzzaU/J7IpKQIP6nM+qPOrNt3LgwS8TfLJXe2hgiKIDT7pzds/YlH/WDYJi1bwxUfgCIM7Zk3QMuLxveaZYTZTnR2xFy3Sx3KcuJaHiuNJUBAGiK59m1aVvFolIrYGbbuHGhQ0WjgKjWt7XJkQGAkHX7zJ+3T3vMIlgGiKCE/PK8xSvGFwo55TgOAwDIZrM8m3X5Bz8aAiQgvO3ZX21iDYdN3Lsr/OWiyed8wykWjXxbmzxoFPct5jWdPOqfOyvbEtqoNaPgqp7F37i51Ska6/Nv2xlExLbuOHtRwq473rInXTq27luDiECPbnNmWbW1Xx0q41VfOvaqlxGB7nv+vkM10VGgNBoM/0hE2FkqvSv2ffcAEWDn15bc18eMxCnCL08AABi1pcQAAM4//8aLIFJnsddfv2wsYuTUN4rsm4ObWhGBiLZbGsTidKNxjlTyQkQgAICq1glNOqGlAk3wBiJS89Rd9F6BdBwHCQgZY4OIDJSkNABAoQCyt7c3IaW6XivjXKbMWGmiQa8qFQe7ftj8GAmk93hDoWLI6kecNmgrYggxMzgwhNFEhP2lw97zePP5PCEgEVEjkQbOWXWfhFYUt5hakxQikMxUR+5FRM9IMA5IjQAAiKgA2S7GGZdajAEYfj+yzf17EfgrzGCkNH0eEd8vGsxxHLziF48eqYmatRTAOfbtE1Ows9wICI1aK85Gjer0APgbnAMQqY+95QXZVq00aYITi1Q0CgUAxLxGYH/QQqDm7OwbNz1yTL6tTc7t7UocgIIItzQ3G/l8Xu+pVDrQSmVk5ItMnf3wyAp+RU3k3DQBCBgiEiLbBkCgQZ8wkq4MzA2RL5AZ/JjKtu0nutmsJiLM2MmusOyHaBqZAPCX9z75ZG335EtE1nV5a7FojAxAhEIuF8+8c81ZEWEHEAHnuPonC8/bns06JgCQEOLLAIy4wfcwAAAE+6k40qC1On7T69d+BACgXo8uBVW5O1VrMk8FcxCRbn3oVrN9/PR/oDYWmaYBguOn+qz4sas3/fXkQi73jndk7fbt5uyVGzoC5Ks0MhNENFCXrlk4nNLN6krnzkOE0tNJazStxBoEANj22pzxsdy12UjVGV6lZv7kcbf/FABgzbbrbjMyqcsGy8wDajjpvAkztzt9rplvycXX9z6wXNU0LCjHHKo+xQLtUqStv4FQofKiI5UXtVKsx0MYQ8IPK/Ukp9++YPpjl99yi7W8oyO6YN4tS1SIV8tKRdSlrSnMIWDHHn7X86TNXiNBFCk5h4gYEWGCapf5Q3Fg2kY6ll4XAMDUXYdpp+gYiyZ/5XLw46uY0oNmTY0JdfVfkPUNi8LaQ76vMvWXYqZmPGMMEghP1lq8dRjEWmt5R0d08dVdJwuNVxABJCy26q67F27EIrUabbhe9u2YOYslRY8f14CIG86ZcvTSBwAAVm25+Ts8bS6txibEUeLW2S2zOlzX5Y8ePci6J18iljz9l6bdzLxgr+Cnl6Xx0SBULBnGvh3L/mSsVnWdu66AmNcznR777nx7ONu564igLJ/QnmyCKCyPrqs5vqHhtVdxpL68Aq79xksP9Fm1yaaBwdTWxmM+e1Kh1K8Xn75Yrnjux2shk/5iNUyAlNYt81q+fgUBwOVr11rLp02LRhKl5+WX7bWcozt2bIyICgAg67r8zf5+XJ/PywU3rfzEwJ7yb6QXj+exAkvHX/9F95W/BsdhOJxpWY5YUM/smPc1MNX9gc6AV00tPeO4667p6p2bGFv7ueRu4T9MydQULzIhUuY6U9csvGziGZv3pSprLZXY+lJJQ2cnQSdg69QSW7+vBiEAzFq2qj2q+j9Qvmw0pAabomt+9qP5S7NZl2ez8HbRcynLc7hSPfHCpQ8aGWtaxU9SHKXPnTbh2tUuuRw2QqacClZoM/1FTyYgCLkvMbmCWLLntMzhG9vGjQsPeNDWPDXmnwPlL0QV/2LliVMxFIB+KEwprrz7prk/mZB1zC2FfHz+jOtWvAWEyGEAedq447oxvtq9SRn2GD9OeVFknjWj5eo/OUXH6Jzaqbr7V323qnGhtGtrQkrCUEVApK0XQpXYFjH7XxQDyYqfwjBu0l7UjJIOxUgBegFwP3jG1uE373Jmb5g0aW5i48ZuMWvWTd3h3vjid9QJ183yXK6gSi98d4pi8jGBdjKQyQrp1IUzPrHgdw45LI95ffuzDx3nMfatIcHOic3MqMisAw9t8CgFItLAKj4wPwAo+6AHBiARis2mkHecVt/Q097eFg6v5fLfP/LaHcITF4ly9UCqWCw6RltbXq7bfsPZiks3BjvpC0sRpPJ8c90Nuf3I7219T415k3RrVfBTKzpx3F6ZqPd9CakoVkYYv2or/VxSUml+y6FPtrS0xCN2HYvvPW7PzvIdwhNTIYwB4uCvB62cRXKMNszLNf1LTtOmcb8wkodH2oIgMv+sIdl58YTcuoPZ4TCHAAYA+iByp2d1/SsvVeeHFX+hCmQDixWgCN1TPtM0511L+EhkVj99c5PKJLoFt8+MwIaKhyAguY5Y+h6TpR+/fPypr72bDwCA3l5K3P3MQy2VSjg9LvsXUqSbKIgBgiA0SS++p6tjCcD7sPiR1gEAYMXzP5vnaf5tZaabYpYGL2RQ8WGPgOQzEu3nfGX+HbhZTigO5cEqJz88QvrRsdqPTtBe0MLJ4OjHQJUqGEI+kmS4qPuHF/UCOAygk96XszqOw/KdeQIE6nl6dX1kidme5BeGZJ2g0odAyNLgKxOqkkNVWSBCBdyLgEUxYCAAvBCgXAW9d6hiKfV4irDrjmvPewgAYP8e5wOT5/2jQ0Rs+bbilLLE06ux8emK5EdXdaKxSpYtQ2UxL/SNUFSNSL5uCNmfkHrDYdx6/Mb2tn8MeyN0nHf2Nh+qwdpHlvl/svY+IvO3W3ccukeLdFLozO6qGBhXV1NZ9MmPDur9OJzjOGxLczMerO38Ny1LrfrtGJskAAAAAElFTkSuQmCC"
try {
    $logoBytes = [System.Convert]::FromBase64String($logoB64)
    $logoStream = New-Object System.IO.MemoryStream(,$logoBytes)
    $logoImage = [System.Drawing.Image]::FromStream($logoStream)
    $logoPic = New-Object System.Windows.Forms.PictureBox
    $logoPic.Image = $logoImage
    $logoPic.SizeMode = "AutoSize"
    $logoPic.BackColor = [System.Drawing.Color]::Transparent
    $logoPic.Location = New-Object System.Drawing.Point(12, 7)
    $brandBar.Controls.Add($logoPic)
    $labelX = 54
} catch {
    $labelX = 12
}

$brandLabel = New-Object System.Windows.Forms.Label
$brandLabel.Text = "CorroHealth  |  Invite External Guests"
$brandLabel.ForeColor = [System.Drawing.Color]::White
$brandLabel.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$brandLabel.AutoSize = $true; $brandLabel.Location = New-Object System.Drawing.Point($labelX, 11)
$brandBar.Controls.Add($brandLabel)

# ---- Info banner ----
$infoPanel = New-Object System.Windows.Forms.Panel
$infoPanel.Dock = "Top"; $infoPanel.Height = 40; $infoPanel.BackColor = $themePanel
$infoLabel = New-Object System.Windows.Forms.Label
$infoLabel.Text = "Invites existing home-tenant users into the external tenant. Never creates or modifies the home-tenant account itself."
$infoLabel.AutoSize = $true; $infoLabel.Location = New-Object System.Drawing.Point(10, 11); $infoLabel.ForeColor = $themeTextMuted
$infoPanel.Controls.Add($infoLabel)

# ---- Toolbar ----
$toolbar = New-Object System.Windows.Forms.FlowLayoutPanel
$toolbar.Dock = "Top"; $toolbar.Height = 40; $toolbar.Padding = New-Object System.Windows.Forms.Padding(8, 6, 8, 6); $toolbar.BackColor = $themePanel
function New-ToolButton($text, $width) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Width = $width; $b.Height = 26; Set-DarkButton $b; return $b
}
$btnAddRow         = New-ToolButton "Add row" 80
$btnPasteUpns      = New-ToolButton "Paste UPNs" 100
$btnUploadCsv      = New-ToolButton "Upload CSV" 95
$btnRemoveSelected = New-ToolButton "Remove selected" 115
$btnSelectAll      = New-ToolButton "Select all" 85
$btnExportResults  = New-ToolButton "Re-export last results" 150
$toolbar.Controls.AddRange([System.Windows.Forms.Control[]]@($btnAddRow, $btnPasteUpns, $btnUploadCsv, $btnRemoveSelected, $btnSelectAll, $btnExportResults))

# ---- Grid ----
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = "Fill"
$grid.AllowUserToAddRows = $false; $grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.RowHeadersVisible = $false
$grid.AutoSizeColumnsMode = "Fill"; $grid.RowTemplate.Height = 26; $grid.SelectionMode = "FullRowSelect"
$grid.BackgroundColor = $themeBg; $grid.GridColor = [System.Drawing.Color]::FromArgb(220, 214, 228); $grid.BorderStyle = "None"; $grid.EnableHeadersVisualStyles = $false
$grid.DefaultCellStyle.BackColor = $themeBg; $grid.DefaultCellStyle.ForeColor = $themeText
$grid.DefaultCellStyle.SelectionBackColor = $corroPurple; $grid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
$grid.AlternatingRowsDefaultCellStyle.BackColor = $themeRowAlt; $grid.AlternatingRowsDefaultCellStyle.ForeColor = $themeText
$grid.AlternatingRowsDefaultCellStyle.SelectionBackColor = $corroPurple; $grid.AlternatingRowsDefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
$grid.ColumnHeadersDefaultCellStyle.BackColor = $themePanel
$grid.ColumnHeadersDefaultCellStyle.ForeColor = $themeHeaderTxt
$grid.ColumnHeadersDefaultCellStyle.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$grid.ColumnHeadersHeight = 28
$grid.ColumnHeadersHeightSizeMode = "DisableResizing"

$colInclude = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$colInclude.Name = "Include"; $colInclude.HeaderText = ""; $colInclude.Width = 34; $colInclude.Resizable = "False"
$colUpn = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colUpn.Name = "Upn"; $colUpn.HeaderText = "User (UPN / email)"; $colUpn.FillWeight = 28
$colFirst = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colFirst.Name = "FirstName"; $colFirst.HeaderText = "First name"; $colFirst.FillWeight = 16
$colLast = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colLast.Name = "LastName"; $colLast.HeaderText = "Last name"; $colLast.FillWeight = 16
$colTitle = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colTitle.Name = "JobTitle"; $colTitle.HeaderText = "Job title (optional)"; $colTitle.FillWeight = 20
$colStatus = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colStatus.Name = "Status"; $colStatus.HeaderText = "Status"; $colStatus.ReadOnly = $true; $colStatus.FillWeight = 34
$colDelete = New-Object System.Windows.Forms.DataGridViewButtonColumn
$colDelete.Name = "Delete"; $colDelete.Text = "Remove"; $colDelete.UseColumnTextForButtonValue = $true; $colDelete.Width = 70; $colDelete.Resizable = "False"
$grid.Columns.AddRange([System.Windows.Forms.DataGridViewColumn[]]@($colInclude, $colUpn, $colFirst, $colLast, $colTitle, $colStatus, $colDelete))

$grid.Add_CellClick({
    param($sender, $e)
    if ($e.RowIndex -lt 0) { return }
    if ($grid.Columns[$e.ColumnIndex].Name -eq "Delete") { $grid.Rows.RemoveAt($e.RowIndex); Update-QueueCount }
})

function Add-GuestRow($upn, $firstName = "", $lastName = "", $jobTitle = "") {
    $upn = $upn.Trim()
    if (-not $upn) { return }
    foreach ($row in $grid.Rows) { if ("$($row.Cells['Upn'].Value)".Trim() -eq $upn) { return } }
    $i = $grid.Rows.Add()
    $grid.Rows[$i].Cells["Include"].Value = $true
    $grid.Rows[$i].Cells["Upn"].Value = $upn
    $grid.Rows[$i].Cells["FirstName"].Value = $firstName
    $grid.Rows[$i].Cells["LastName"].Value = $lastName
    $grid.Rows[$i].Cells["JobTitle"].Value = $jobTitle
}

# ---- Action bar ----
$actionBar = New-Object System.Windows.Forms.Panel
$actionBar.Dock = "Bottom"; $actionBar.Height = 50; $actionBar.Padding = New-Object System.Windows.Forms.Padding(8); $actionBar.BackColor = $themePanel
$lblCount = New-Object System.Windows.Forms.Label
$lblCount.AutoSize = $true; $lblCount.Text = "0 users queued"; $lblCount.Location = New-Object System.Drawing.Point(8, 8); $lblCount.ForeColor = $themeText
$lblProgress = New-Object System.Windows.Forms.Label
$lblProgress.AutoSize = $true; $lblProgress.Text = ""; $lblProgress.Location = New-Object System.Drawing.Point(8, 28); $lblProgress.ForeColor = $corroPurple
$btnRun = New-Object System.Windows.Forms.Button
$btnRun.Text = "Send invites"; $btnRun.Width = 130; $btnRun.Height = 32; $btnRun.Anchor = "Right"
Set-DarkButton $btnRun -Accent
$actionBar.Controls.AddRange([System.Windows.Forms.Control[]]@($lblCount, $lblProgress, $btnRun))
$actionBar.Add_Resize({ $btnRun.Location = New-Object System.Drawing.Point(($actionBar.Width - 145), 9) })

$form.Controls.Add($grid)
$form.Controls.Add($actionBar)
$form.Controls.Add($toolbar)
$form.Controls.Add($infoPanel)
$form.Controls.Add($brandBar)

function Update-QueueCount {
    $n = 0
    foreach ($row in $grid.Rows) { if ($row.Cells["Include"].Value -eq $true -and "$($row.Cells['Upn'].Value)".Trim()) { $n++ } }
    $lblCount.Text = "$n user(s) queued"
}
$grid.Add_CellValueChanged({ Update-QueueCount })
$grid.Add_CurrentCellDirtyStateChanged({ if ($grid.IsCurrentCellDirty) { $grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit) } })

# Allow pasting directly into whatever cell is selected, without needing to
# double-click/F2 into edit mode first.
$grid.Add_KeyDown({
    param($sender, $e)
    if ($e.Control -and $e.KeyCode -eq "V") {
        if (-not [System.Windows.Forms.Clipboard]::ContainsText()) { return }
        $clip = [System.Windows.Forms.Clipboard]::GetText()
        $cell = $grid.CurrentCell
        if ($cell -and -not $cell.ReadOnly) {
            $firstToken = ($clip -split "[\r\n\t]")[0]
            $cell.Value = $firstToken
            $e.Handled = $true
            $e.SuppressKeyPress = $true
        }
    }
})

# ---- Toolbar button handlers ----
$btnAddRow.Add_Click({ $i = $grid.Rows.Add(); $grid.Rows[$i].Cells["Include"].Value = $true; Update-QueueCount })
$btnSelectAll.Add_Click({ foreach ($row in $grid.Rows) { $row.Cells["Include"].Value = $true }; Update-QueueCount })
$btnRemoveSelected.Add_Click({
    $toRemove = @(); foreach ($row in $grid.Rows) { if ($row.Cells["Include"].Value -eq $true) { $toRemove += $row } }
    foreach ($row in $toRemove) { $grid.Rows.Remove($row) }; Update-QueueCount
})

$btnPasteUpns.Add_Click({
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Paste UPNs"; $dlg.Size = New-Object System.Drawing.Size(420, 340); $dlg.StartPosition = "CenterParent"
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Paste one UPN / email per line (name/title can be filled in after):"; $lbl.AutoSize = $true; $lbl.Location = New-Object System.Drawing.Point(10, 10)
    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Multiline = $true; $txt.ScrollBars = "Vertical"; $txt.Location = New-Object System.Drawing.Point(10, 32); $txt.Size = New-Object System.Drawing.Size(390, 220)
    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = "Add to grid"; $btnOk.Location = New-Object System.Drawing.Point(230, 262); $btnOk.DialogResult = "OK"
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"; $btnCancel.Location = New-Object System.Drawing.Point(325, 262); $btnCancel.DialogResult = "Cancel"
    $dlg.Controls.AddRange([System.Windows.Forms.Control[]]@($lbl, $txt, $btnOk, $btnCancel))
    $dlg.AcceptButton = $btnOk; $dlg.CancelButton = $btnCancel
    Set-DarkForm $dlg; $lbl.ForeColor = $themeText
    $txt.BackColor = $themeControl; $txt.ForeColor = $themeText; $txt.BorderStyle = "FixedSingle"
    Set-DarkButton $btnOk -Accent; Set-DarkButton $btnCancel
    if ($dlg.ShowDialog() -eq "OK") {
        $lines = $txt.Text -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        foreach ($line in $lines) { Add-GuestRow $line }
        Update-QueueCount
    }
})

$btnUploadCsv.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*"
    $ofd.Title = "Select a CSV with a UserPrincipalName column"
    if ($ofd.ShowDialog() -ne "OK") { return }
    try {
        $rows = Import-Csv -Path $ofd.FileName -ErrorAction Stop
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not read that CSV:`n`n$($_.Exception.Message)", "Upload failed", "OK", "Error") | Out-Null
        return
    }
    if ($rows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("That CSV has no data rows.", "Nothing to import", "OK", "Information") | Out-Null
        return
    }
    # Accepts the main wizard's own results CSV directly (FirstName,
    # LastName, UserPrincipalName, ...), not just a hand-made file.
    $sample = $rows[0]
    $propNames = $sample.PSObject.Properties.Name
    $upnProp   = $propNames | Where-Object { $_ -in @("UserPrincipalName","UPN","Upn","Email","EmailAddress") } | Select-Object -First 1
    $firstProp = $propNames | Where-Object { $_ -in @("FirstName","GivenName") } | Select-Object -First 1
    $lastProp  = $propNames | Where-Object { $_ -in @("LastName","Surname") } | Select-Object -First 1
    $titleProp = $propNames | Where-Object { $_ -in @("JobTitle","Designation","Title") } | Select-Object -First 1
    if (-not $upnProp) {
        [System.Windows.Forms.MessageBox]::Show("Couldn't find a UserPrincipalName (or UPN/Email) column in that CSV.`n`nColumns found: $($propNames -join ', ')", "Column not found", "OK", "Error") | Out-Null
        return
    }
    $added = 0
    foreach ($r in $rows) {
        $upnVal = "$($r.$upnProp)".Trim()
        if (-not $upnVal) { continue }
        $fnVal = if ($firstProp) { "$($r.$firstProp)".Trim() } else { "" }
        $lnVal = if ($lastProp) { "$($r.$lastProp)".Trim() } else { "" }
        $ttVal = if ($titleProp) { "$($r.$titleProp)".Trim() } else { "" }
        Add-GuestRow $upnVal $fnVal $lnVal $ttVal
        $added++
    }
    Update-QueueCount
    $mappedNote = "Mapped: $upnProp -> UPN" + $(if ($firstProp) { ", $firstProp -> First" }) + $(if ($lastProp) { ", $lastProp -> Last" }) + $(if ($titleProp) { ", $titleProp -> Job title" })
    [System.Windows.Forms.MessageBox]::Show("Added $added user(s).`n`n$mappedNote", "CSV loaded", "OK", "Information") | Out-Null
})

# ============================================================
#  Run: invite every checked, non-blank user into the external tenant
# ============================================================
$btnRun.Add_Click({
    $runTimestamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"

    $rowsToProcess = @()
    foreach ($row in $grid.Rows) {
        $upn = "$($row.Cells['Upn'].Value)".Trim()
        if ($row.Cells["Include"].Value -eq $true -and $upn) { $rowsToProcess += $row }
    }
    if ($rowsToProcess.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No checked users with a UPN to process.", "Nothing to run", "OK", "Warning") | Out-Null
        return
    }

    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "This will invite $($rowsToProcess.Count) existing user(s) as B2B guests into the external tenant. No home-tenant account is created or modified. Continue?",
        "Confirm invites", "YesNo", "Question")
    if ($confirm -ne "Yes") { return }

    $btnRun.Enabled = $false; $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    $results = New-Object System.Collections.ArrayList
    $processed = 0
    $succeeded = 0
    $failed = 0
    foreach ($row in $rowsToProcess) {
        $processed++
        $upn = "$($row.Cells['Upn'].Value)".Trim()
        $fn = "$($row.Cells['FirstName'].Value)".Trim()
        $ln = "$($row.Cells['LastName'].Value)".Trim()
        $jt = "$($row.Cells['JobTitle'].Value)".Trim()
        $fullName = if ($fn -or $ln) { "$fn $ln".Trim() } else { $upn }

        $lblProgress.Text = "Inviting $upn ($processed of $($rowsToProcess.Count))..."; [System.Windows.Forms.Application]::DoEvents()

        $notes = @()
        try {
            $inv = New-MgInvitation `
                -InvitedUserEmailAddress $upn `
                -InvitedUserDisplayName $fullName `
                -SendInvitationMessage:$false `
                -InviteRedirectUrl $externalInviteRedirectUrl `
                -ErrorAction Stop
            $notes += "External invite sent"
            $succeeded++

            if ($fn -or $ln -or $jt) {
                $patchParams = @{}
                if ($fn) { $patchParams["GivenName"] = $fn }
                if ($ln) { $patchParams["Surname"] = $ln }
                if ($jt) { $patchParams["JobTitle"] = $jt }
                try {
                    Update-MgUser -UserId $inv.InvitedUser.Id @patchParams -ErrorAction Stop
                    $notes += "External profile set"
                } catch {
                    $notes += "External profile update FAILED: $($_.Exception.Message)"
                }
            }
        } catch {
            $notes += "External invite FAILED: $($_.Exception.Message)"
            $failed++
        }

        $statusText = ($notes -join " | ")
        $row.Cells["Status"].Value = $statusText
        [void]$results.Add([PSCustomObject]@{ UserPrincipalName = $upn; FirstName = $fn; LastName = $ln; JobTitle = $jt; Status = $statusText })
    }

    $lblProgress.Text = "Done - $($rowsToProcess.Count) user(s) processed."

    $resultsPath = Join-Path $scriptDir "InviteExternalGuests_Results_$runTimestamp.csv"
    try {
        $results | Export-Csv -Path $resultsPath -NoTypeInformation -ErrorAction Stop
        $exportNote = "Results saved to:`n$resultsPath"
    } catch {
        $exportNote = "Could not save results file: $($_.Exception.Message)"
    }
    $script:lastResults = $results
    $script:lastResultsPath = $resultsPath

    [System.Windows.Forms.MessageBox]::Show(
        "Run finished.`n`nUsers processed: $($rowsToProcess.Count)`nInvited: $succeeded   Failed: $failed`n`nSee the Status column for per-user detail.`n`n$exportNote",
        "Invite run complete", "OK", "Information") | Out-Null

    $form.Cursor = [System.Windows.Forms.Cursors]::Default; $btnRun.Enabled = $true
})

$btnExportResults.Add_Click({
    if (-not $script:lastResults -or $script:lastResults.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No run has completed yet in this session, so there's nothing to export.", "Nothing to export", "OK", "Information") | Out-Null
        return
    }
    $reExportPath = Join-Path $scriptDir "InviteExternalGuests_Results_$(Get-Date -Format 'yyyyMMdd_HHmmss_fff')_reexport.csv"
    try {
        $script:lastResults | Export-Csv -Path $reExportPath -NoTypeInformation -ErrorAction Stop
        [System.Windows.Forms.MessageBox]::Show("Last run's results (from $script:lastResultsPath) re-exported to:`n`n$reExportPath", "Re-export complete", "OK", "Information") | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not re-export results:`n`n$($_.Exception.Message)", "Re-export failed", "OK", "Error") | Out-Null
    }
})

$form.Add_FormClosing({ try { Stop-Transcript | Out-Null } catch {} })
[System.Windows.Forms.Application]::Run($form)

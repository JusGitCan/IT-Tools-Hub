# CorroHealth User Management Toolkit

Four standalone WinForms tools for one-off, mass maintenance actions on
**existing** Entra ID / Microsoft 365 users. Each is independent — pick
the one you need and launch only it.

None of these create new users. That's what the **User Provisioning
Wizard** (separate tile on the hub) is for. These four exist for fixing
or updating users who already exist:

| Tool | Use it when... |
|---|---|
| **Add Users To Group** | A group got missed during a bulk import and you need to add existing users to it after the fact. |
| **Invite External Guests** | A batch predates the wizard's external-invite step, or an invite failed and needs a clean retry. |
| **Reset User Passwords** | A batch was accidentally created with one shared password and needs individual passwords fixed. |
| **Update User Job Info** | Job Title and/or Employee ID need a mass update — reorgs, title corrections, or a contractor converting to full-time. |

See each tool's own `README-*.md` for details.

## Running any of these tools
1. Unzip this bundle to its own folder — keep each tool's `.ps1` and
   `.bat` together.
2. Double-click the matching **Launch-\*.bat** file. Do not run the
   `.ps1` directly, and do not launch via VS Code's F5 — both skip the
   STA mode the sign-in UI requires and can throw a "single-threaded
   apartment" error.
3. Sign in with your own admin credentials when prompted.

## Safety, across all four
- None of these tools ever create or delete a user account.
- Each only touches the specific field(s) named in its own README —
  nothing else about the account is modified.
- If a user (or group) can't be found, that row is noted in Status and
  the rest of the batch keeps going — one bad row never stops a run.
- Every run saves its own results CSV and PowerShell transcript next to
  the script, so there's always a record of exactly what happened.

## Support
Structure-verified before release, but not runtime-tested against a live
tenant by the tool's author. Test on a couple of throwaway or known-safe
accounts before running a real batch, especially after any update.

# Update User Job Info

Mass-updates **existing** users' Job Title and/or Employee ID — e.g.
after a reorg, a department rename, a batch of title corrections from
HR, or a contractor converting to full-time and getting issued a new
Employee ID.

## What it does
- Job Title and Employee ID are updated **independently per row** — a
  row can change one, the other, or both. Leaving a field blank for a
  row means that field is left untouched on that user.
- **Employee ID mirroring** — CorroHealth also stores a copy of the
  Employee ID in the "Preferred data location" field (Graph:
  `preferredDataLocation`). Whenever a row sets a new Employee ID, this
  tool automatically writes the same value to Preferred data location
  too — there's no separate input for it, the two fields are always
  kept in sync from one entry.

## Bringing in users
- **Manual entry** — type directly into the grid.
- **Paste list** — `UPN, New Title, New Employee ID` per line, leave a
  field blank between commas to skip it.
- **Upload CSV** — matches a UPN column, a Job Title column, and an
  Employee ID column by header text (several common header spellings
  accepted for each).

## What it never does
- Never creates, disables, licenses, or otherwise modifies a user
  account beyond Job Title / Employee ID / Preferred data location (the
  last one only as a mirror of Employee ID, never independently).
- If a user can't be found, or an update fails, that row is noted in
  Status and the rest of the batch keeps going.

## How to run it
Always launch via **Launch-UpdateUserJobInfo.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat`
forces Windows PowerShell into STA mode, which the sign-in UI
requires — running the `.ps1` on its own can throw a "single-threaded
apartment" error.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in only — no Exchange Online
connection is made, since both Job Title and Employee ID are Graph-only
properties (`Update-MgUser -JobTitle` / `-EmployeeId`).

## Results
A per-run results CSV and PowerShell transcript are saved next to the
script after each run.

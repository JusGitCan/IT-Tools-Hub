# User Admin Toolkit

Mass-updates **existing** Entra ID / Microsoft 365 users across three
actions — **License, Group membership, and Invite as External Guest**
— from a single grid. Replaces the three separate tools this bundle
used to ship (**Add User License**, **Add Users To Group**, and
**Invite External Guests**).

Job Title / Employee ID updates are a **separate tool** —
**Update User Job Info** — deliberately not merged into this one. See
`README-UpdateUserJobInfo.md`.

## One row, any combination
Each row is one user. License Tier, Group(s), and Invite as Guest are
independent — fill in whatever applies to that person and leave the
rest blank. A single row can do one action, two, or all three; the Run
button only performs what's actually filled in for that row, and the
Status column reports each action's outcome separately (e.g.
`License: E3 added | Added to All-Coders (Entra ID) | External invite
sent`), so you can see exactly what happened per person even when
several ran at once.

## Two tenants, one tool
License and Group actions run against your **home tenant** (connected
at launch). Invite as Guest runs against a **separate external
tenant** — same target tenant and redirect URL the main Wizard uses.
Rather than switching tenant context per row, Run processes the whole
batch in two phases:

1. **Phase 1 (home tenant)** — every row with a License Tier and/or
   Group(s) filled in gets processed first.
2. **Phase 2 (external tenant)** — only if at least one checked row has
   **Invite as Guest** checked, the tool switches to the external
   tenant, sends every queued invite, then switches back to the home
   tenant before the run finishes.

This mirrors how the main Wizard sequences the same two tenants, and
means a run that's only touching License/Groups never prompts for an
external sign-in, and a run that's only sending invites never needs a
home-tenant user lookup.

## License
Mode (Domestic / Global, toggled at the top) controls what "F3+" means
and whether E5 is offered — identical mapping to
`UserProvisioningWizard.ps1`:

| Tier | Domestic | Global |
|---|---|---|
| F3 | SPE_F1 | SPE_F1 |
| F3+ | F3 + Apps for Enterprise | F3 + Exchange Archive (50GB) + Apps for Enterprise |
| E3 | SPE_E3 | SPE_E3 + Apps for Enterprise |
| E5 | SPE_E5 | not offered |

Apps for Enterprise is applied **automatically** based on tier + mode —
there's no separate Y/N column to set. License assignment is additive
only: `Set-MgUserLicense` is always called with an empty
`RemoveLicenses` list, so an existing license is never removed or
swapped.

### UsageLocation
Microsoft Graph rejects any license assignment for an account with no
`UsageLocation` set. This tool checks and self-heals *only* when it's
safe to be certain of the value:
- **Domestic mode** — a blank UsageLocation is set to `US`
  automatically, noted in Status.
- **Global mode** covers both US and India, so a blank value is never
  guessed — that row's license action is skipped with a message telling
  you to set it manually first.
- An account that already has a UsageLocation is never overwritten.

## Group membership
Correctly routes Microsoft 365 Groups and Entra ID security groups
through Microsoft Graph, and only true mail-enabled distribution lists
through Exchange Online. Exchange Online is only connected at Run time,
and only if at least one checked row actually has a Group filled in —
a run that's only touching License never prompts for an Exchange
sign-in.

Each row has its own Group(s) cell (comma-separated), so different
users in the same batch can go to different groups.

## Invite as External Guest
Invites an existing **home tenant** user as a B2B guest into the
**external tenant** — same as the Wizard's own "Invite external user
(Preview)" step: same UPN as the invited email, no invite email sent,
first/last name and job title (if filled in) copied to the guest's
external profile, no groups or roles assigned by the invite itself.

Never creates or modifies the home-tenant account — the invite is a
separate object in the separate external tenant.

- **Invite as Guest** — a checkbox column; checking it is what flags
  the row for Phase 2. Nothing else about that row is required.
- **Guest First Name / Last Name / Job Title** — all optional. Left
  blank, the guest's display name falls back to the UPN, same as the
  original Invite tool.

## Bringing in users
- **Manual entry** — type directly into the grid; License Tier is a
  dropdown so you can't type an invalid value. Adding the same UPN
  twice merges into the existing row rather than duplicating it,
  filling in only whatever blank fields the new entry provides.
- **Paste list** — one user per line: `UPN, Tier, Invite(Y/N), Group1,
  Group2`. Leave a field blank between commas to skip it. The line is
  split on the first three commas only, so everything after the third
  comma — however many commas it contains — is taken as the Groups
  list intact. Guest First/Last Name and Job Title are deliberately
  **not** part of paste (same as the original Invite tool, which only
  ever pasted bare UPNs) — fill those in manually or via CSV afterward
  if you want a nicer guest display name than the UPN.
- **Upload CSV** — matches a UPN column plus any mix of Tier, Groups,
  Invite, Guest First Name, Guest Last Name, and Guest Job Title
  columns by header text; none are required. Also accepts the main
  Wizard's own results CSV directly (`FirstName`/`LastName`/`JobTitle`
  headers map straight to the guest fields).
- **Bulk-apply panel** — set a Tier and/or Group(s) onto every checked
  row, and/or check "Invite as Guest" on every checked row, all at
  once. Guest First/Last Name and Job Title are intentionally **not**
  bulk-appliable, since they're inherently per-person. Still editable
  per-row afterward for anyone who needs something different.

## What it never does
- Never creates, disables, or renames the home-tenant user account.
- Never touches Job Title, Employee ID, Preferred Data Location, or
  passwords on the home-tenant account.
- Never removes an existing license or group membership — only
  adds/sets what's specified.
- If a user or group can't be found, or an individual action fails,
  that's noted in Status and the rest of the batch keeps going.
- The License Tier dropdown itself won't offer E5 while in Global mode,
  and the Run button double-checks before every run.
- A confirmation dialog appears before any invites are sent, naming how
  many guests are about to be invited.

## How to run it
Always launch via **Launch-UserAdminToolkit.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat`
forces Windows PowerShell into STA mode, which the sign-in UI
requires — running the `.ps1` on its own can throw a "single-threaded
apartment" error.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in to the **home tenant**
(`User.ReadWrite.All`, `Group.ReadWrite.All`) up front. Exchange Online
is only connected at Run time, and only if the batch needs it (see
**Group membership** above). A second sign-in to the **external
tenant** (`User.Invite.All`, `User.ReadWrite.All`) only happens at Run
time, and only if at least one checked row has Invite as Guest checked
— the tool switches back to the home tenant automatically once invites
are done.

## Results
A per-run results CSV (with columns for Tier, Groups Requested, Invite
Requested, and Guest First/Last Name/Job Title per row) and PowerShell
transcript are saved next to the script after each run, plus a
"Re-export last results" button as backup.

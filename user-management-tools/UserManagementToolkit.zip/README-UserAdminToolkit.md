# User Admin Toolkit

Mass-updates **existing** Entra ID / Microsoft 365 users across four
actions — **License, Group membership, Job Title, and Invite as
External Guest** — from a single grid. Replaces the three separate
tools this bundle used to ship (**Add User License**, **Add Users To
Group**, and **Invite External Guests**).

**Job Title lives in two places on purpose.** It's here *and* in the
standalone **Update User Job Info** tool — that overlap is deliberate.
Employee ID is NOT duplicated here; it stays exclusively in
`README-UpdateUserJobInfo.md`.

## One row, any combination
Each row is one user. License Tier, Group(s), Job Title, and Invite as
Guest are independent — fill in whatever applies to that person and
leave the rest blank. A single row can do one action, several, or all
four; the Run button only performs what's actually filled in for that
row, and the Status column reports each action's outcome separately
(e.g. `Job title updated to 'Analyst' | License: E3 added | Added to
All-Coders (Entra ID) | External invite sent`), so you can see exactly
what happened per person even when several ran at once.

## Two tenants, one tool
License and Group actions run against your **home tenant** (connected
at launch). Invite as Guest runs against a **separate external
tenant** — same target tenant and redirect URL the main Wizard uses.
Rather than switching tenant context per row, Run processes the whole
batch in two phases:

1. **Phase 1 (home tenant)** — every row with a License Tier and/or
   Group(s) filled in gets processed first.
2. **Phase 2 (external tenant)** — only if at least one checked row has
   **Invite as Guest** checked, the tool switches to the external
   tenant, sends every queued invite, then switches back to the home
   tenant before the run finishes.

This mirrors how the main Wizard sequences the same two tenants, and
means a run that's only touching License/Groups never prompts for an
external sign-in, and a run that's only sending invites never needs a
home-tenant user lookup.

## License
Mode (Domestic / Global, toggled at the top) controls what "F3+" means
and whether E5 is offered — identical mapping to
`UserProvisioningWizard.ps1`:

| Tier | Domestic | Global |
|---|---|---|
| F3 | SPE_F1 | SPE_F1 |
| F3+ | F3 + Apps for Enterprise | F3 + Exchange Archive (50GB) + Apps for Enterprise |
| E3 | SPE_E3 | SPE_E3 + Apps for Enterprise |
| E5 | SPE_E5 | not offered |

Apps for Enterprise is applied **automatically** based on tier + mode —
there's no separate Y/N column to set. License assignment is additive
only: `Set-MgUserLicense` is always called with an empty
`RemoveLicenses` list, so an existing license is never removed or
swapped.

### UsageLocation
Microsoft Graph rejects any license assignment for an account with no
`UsageLocation` set. This tool checks and self-heals *only* when it's
safe to be certain of the value:
- **Domestic mode** — a blank UsageLocation is set to `US`
  automatically, noted in Status.
- **Global mode** covers both US and India, so a blank value is never
  guessed — that row's license action is skipped with a message telling
  you to set it manually first.
- An account that already has a UsageLocation is never overwritten.

## Group membership
Correctly routes Microsoft 365 Groups and Entra ID security groups
through Microsoft Graph, and only true mail-enabled distribution lists
through Exchange Online. Exchange Online is only connected at Run time,
and only if at least one checked row actually has a Group filled in —
a run that's only touching License never prompts for an Exchange
sign-in.

Each row has its own Group(s) cell (comma-separated), so different
users in the same batch can go to different groups.

## Job Title
Calls `Update-MgUser -JobTitle`. Nothing else about the home-tenant
account is touched by this field — no Employee ID, no Preferred Data
Location (that mirroring is `UpdateUserJobInfo.ps1`'s behavior, not
this tool's).

If a row updates Job Title **and** is also invited as a guest in the
same run, the invited guest's external profile reflects the **new**
title, not the one that was on file before the run started.

## Invite as External Guest
Invites an existing **home tenant** user as a B2B guest into the
**external tenant** — same as the Wizard's own "Invite external user
(Preview)" step: same UPN as the invited email, no invite email sent,
first/last name and job title copied to the guest's external profile,
no groups or roles assigned by the invite itself.

Never creates or modifies the home-tenant account — the invite is a
separate object in the separate external tenant.

**Just a checkbox.** There's no manual name/title entry anywhere —
during Phase 1's home-tenant lookup, the tool reads each checked user's
**existing** `GivenName` / `Surname` / `JobTitle` straight from their
home-tenant profile and reuses it for the guest's external profile.
If a user has no home-tenant profile fields set, the invite still goes
through; the guest's display name just falls back to the UPN, same as
if those fields had been left blank by hand.

If the home-tenant user can't be found at all, the invite for that row
is skipped — this tool only ever invites users confirmed to already
exist in the home tenant.

## Bringing in users
- **Manual entry** — type directly into the grid; License Tier is a
  dropdown so you can't type an invalid value. Adding the same UPN
  twice merges into the existing row rather than duplicating it,
  filling in only whatever blank fields the new entry provides.
- **Paste list** — one user per line: `UPN, Tier, Invite(Y/N), Job
  Title, Group1, Group2`. Leave a field blank between commas to skip
  it. The line is split on the first four commas only, so everything
  after the fourth comma — however many commas it contains — is taken
  as the Groups list intact.
- **Upload CSV** — matches a UPN column plus any mix of Tier, Groups,
  Invite, and Job Title columns by header text; none are required.
- **Bulk-apply panel** — set a Tier, Group(s), and/or Job Title onto
  every checked row, and/or check "Invite as Guest" on every checked
  row, all at once. Still editable per-row afterward for anyone who
  needs something different.

## What it never does
- Never creates, disables, or renames the home-tenant user account.
- Never touches Employee ID, Preferred Data Location, or passwords on
  the home-tenant account. Job Title IS touched - see above.
- Never removes an existing license or group membership — only
  adds/sets what's specified.
- If a user or group can't be found, or an individual action fails,
  that's noted in Status and the rest of the batch keeps going.
- The License Tier dropdown itself won't offer E5 while in Global mode,
  and the Run button double-checks before every run.
- A confirmation dialog appears before any invites are sent, naming how
  many guests are about to be invited.

## How to run it
Always launch via **Launch-UserAdminToolkit.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat`
forces Windows PowerShell into STA mode, which the sign-in UI
requires — running the `.ps1` on its own can throw a "single-threaded
apartment" error.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in to the **home tenant**
(`User.ReadWrite.All`, `Group.ReadWrite.All`) up front. Exchange Online
is only connected at Run time, and only if the batch needs it (see
**Group membership** above). A second sign-in to the **external
tenant** (`User.Invite.All`, `User.ReadWrite.All`) only happens at Run
time, and only if at least one checked row has Invite as Guest checked
— the tool switches back to the home tenant automatically once invites
are done.

## Results
A per-run results CSV (with columns for Tier, Groups Requested, Job
Title Requested, Invite Requested, and the Home Given Name/Surname/Job
Title that was actually used for any invite, per row) and PowerShell
transcript are saved next to the script after each run, plus a
"Re-export last results" button as backup.

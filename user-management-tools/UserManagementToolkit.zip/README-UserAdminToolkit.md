# User Admin Toolkit

Mass-updates **existing** Entra ID / Microsoft 365 users across three
actions — **License, Job Title, and Group membership** — from a single
grid. Replaces the three separate tools this bundle used to ship
(**Add User License**, **Update User Job Info**, **Add Users To
Group**).

## One row, any combination
Each row is one user. License Tier, Job Title, and Group(s) are three
independent columns — fill in whatever applies to that person and leave
the rest blank. A single row can do one action, two, or all three; the
Run button only performs what's actually filled in for that row, and
the Status column reports each action's outcome separately (e.g.
`License: E3 added | Job title updated to 'Analyst'`), so you can see
exactly what happened per person even when several things ran at once.

## License
Mode (Domestic / Global, toggled at the top) controls what "F3+" means
and whether E5 is offered — identical mapping to
`UserProvisioningWizard.ps1`:

| Tier | Domestic | Global |
|---|---|---|
| F3 | SPE_F1 | SPE_F1 |
| F3+ | F3 + Apps for Enterprise | F3 + Exchange Archive (50GB) + Apps for Enterprise |
| E3 | SPE_E3 | SPE_E3 + Apps for Enterprise |
| E5 | SPE_E5 | not offered |

Apps for Enterprise is applied **automatically** based on tier + mode —
there's no separate Y/N column to set. License assignment is additive
only: `Set-MgUserLicense` is always called with an empty
`RemoveLicenses` list, so an existing license is never removed or
swapped.

### UsageLocation
Microsoft Graph rejects any license assignment for an account with no
`UsageLocation` set. This tool checks and self-heals *only* when it's
safe to be certain of the value:
- **Domestic mode** — a blank UsageLocation is set to `US`
  automatically, noted in Status.
- **Global mode** covers both US and India, so a blank value is never
  guessed — that row's license action is skipped with a message telling
  you to set it manually first.
- An account that already has a UsageLocation is never overwritten.

## Job Title
Calls `Update-MgUser -JobTitle`. Nothing else about the account is
touched — no Employee ID, no Preferred Data Location, no department.

## Group membership
Correctly routes Microsoft 365 Groups and Entra ID security groups
through Microsoft Graph, and only true mail-enabled distribution lists
through Exchange Online. Exchange Online is only connected at Run time,
and only if at least one checked row actually has a Group filled in —
a run that's only touching License and/or Job Title never prompts for
an Exchange sign-in.

Each row has its own Group(s) cell (comma-separated), so different
users in the same batch can go to different groups.

## Bringing in users
- **Manual entry** — type directly into the grid; License Tier is a
  dropdown so you can't type an invalid value. Adding the same UPN
  twice merges into the existing row rather than duplicating it,
  filling in only whatever blank fields the new entry provides.
- **Paste list** — one user per line:
  `UPN, Tier, Job Title, Group1, Group2`. Leave a field blank between
  commas to skip it. The line is split on the first three commas only,
  so everything after the third comma — however many commas it
  contains — is taken as the Groups list intact.
- **Upload CSV** — matches a UPN column plus any mix of a Tier,
  JobTitle, and Groups column by header text; none of the three is
  required.
- **Bulk-apply panel** — set a Tier and/or Job Title and/or Group(s)
  onto every checked row at once, still editable per-row afterward for
  anyone who needs something different.

## What it never does
- Never creates, disables, or renames a user account.
- Never touches Employee ID, Preferred Data Location, or passwords.
- Never removes an existing license, group membership, or job title —
  only adds/sets what's specified.
- If a user or group can't be found, or an individual action fails,
  that's noted in Status and the rest of the batch keeps going.
- The License Tier dropdown itself won't offer E5 while in Global mode,
  and the Run button double-checks before every run.

## How to run it
Always launch via **Launch-UserAdminToolkit.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat`
forces Windows PowerShell into STA mode, which the sign-in UI
requires — running the `.ps1` on its own can throw a "single-threaded
apartment" error.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in (`User.ReadWrite.All`,
`Group.ReadWrite.All`) up front. Exchange Online is only connected at
Run time, and only if the batch needs it (see **Group membership**
above).

## Results
A per-run results CSV (with columns for Tier, Job Title, and Groups
Requested per row) and PowerShell transcript are saved next to the
script after each run, plus a "Re-export last results" button as
backup.

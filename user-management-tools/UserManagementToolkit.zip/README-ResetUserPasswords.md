# Reset User Passwords

Gives **existing** users a new password — for fixing a batch that was
accidentally created with a single shared password, or for a batch that
genuinely needs the same password on purpose (e.g. a quick onboarding
handoff).

## What it does
- Add users one at a time, paste a list of UPNs/emails, or type directly
  into the grid.
- Three password modes:
  - **Auto-generate a unique 16-character password per user**
    (recommended, default)
  - **Prefix + random 5-digit suffix per user** (e.g.
    `CorroHealth@@34961`) — each user still gets a different password,
    just in a predictable format if that's preferred for a handoff sheet.
  - **One shared password for the whole batch** (not recommended) — see
    below.
- Click **Reset passwords** to reset every checked row.

## Shared password mode — read this first
This mode exists on request, with the risk explicitly acknowledged: a
single leaked password compromises **every** account in the batch at
once, not just one — the exact problem this tool otherwise exists to
fix. It's not hidden behind anything subtle: the option is labeled "not
recommended" in red in the UI, and a distinct confirmation dialog spells
out the risk again before it runs.

A **"Force password change at next sign-in"** checkbox sits next to the
shared password field, checked by default so the shared value is only
ever usable once — but it can be unchecked per run if that's not wanted
(e.g. an admin doing initial account setup themselves before handing an
account off, where an immediate forced change would just get in the way).
The confirmation dialog and the completion message both reflect whichever
way it's set for that run.

There's no minimum length enforced on the shared password — it's on the
person running this to judge how strong it needs to be for their
situation.

## What it never does
- Never creates, disables, licenses, or otherwise modifies a user account
  — only the password is touched.
- If a user can't be found or a reset fails, that row is noted in Status
  and the rest of the batch keeps going.

## How to run it
Always launch via **Launch-ResetUserPasswords.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat` forces
Windows PowerShell into STA mode, which the sign-in UI requires.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in using your own admin credentials.

## Results
A per-run results CSV (including the new passwords — handle it like any
credential export) and PowerShell transcript are saved next to the script
after each run.

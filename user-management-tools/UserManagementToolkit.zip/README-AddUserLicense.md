# Add User License

Mass-assigns a license tier to **existing** users — e.g. a batch that
went out without a license, or upgrading a group of users to a higher
tier.

## Additive only
This tool is **additive only**. It never removes or swaps an existing
license — `Set-MgUserLicense` is always called with an empty
`RemoveLicenses` list, exactly like the main wizard. If a user already
has the license being added, Graph just no-ops that part safely.

## Same tier system as the Wizard
Mode (Domestic / Global, toggled at the top) controls what "F3+" means
and whether E5 is offered — identical mapping to
`UserProvisioningWizard.ps1`:

| Tier | Domestic | Global |
|---|---|---|
| F3 | SPE_F1 | SPE_F1 |
| F3+ | F3 + Apps for Enterprise | F3 + Exchange Archive (50GB mailbox) |
| E3 | SPE_E3 | SPE_E3 |
| E5 | SPE_E5 | not offered |
| + Apps for Ent. | Adds Apps for Enterprise on top of any tier above | same |

One license tier is added per row per run (plus the EntApps add-on as an
optional extra on top of it).

## Bringing in users
- **Manual entry** — type directly into the grid; Tier and EntApps are
  dropdowns so you can't type an invalid value.
- **Paste list** — `UPN, Tier, EntApps(Y/N)` per line, EntApps optional.
- **Upload CSV** — matches a UPN column and a License/Tier column by
  header text, plus an optional EntApps column.
- **Bulk-apply panel** — set one Tier and/or EntApps value onto every
  checked row at once.

## What it never does
- Never creates, disables, renames, or removes an existing license from
  a user account.
- Never touches Job Title, Employee ID, groups, or passwords.
- If a user can't be found, or an assignment fails, that row is noted in
  Status and the rest of the batch keeps going.
- The dropdown itself won't offer E5 while in Global mode, and the Run
  button double-checks before every run — E5 can't accidentally get
  applied under Global.

## UsageLocation
Microsoft Graph rejects any license assignment for an account with no
`UsageLocation` set (licensing eligibility is country-dependent) — a
common gap on accounts not created through the main Wizard, which sets
this automatically at creation time.

This tool checks for it and self-heals *only* when it's safe to be
certain of the value:
- **Domestic mode** is always US (locked, same convention as the
  Wizard) — a blank UsageLocation is filled in with `US` automatically,
  noted in Status.
- **Global mode** covers both US and India, so a blank value is never
  guessed — that row is skipped with a clear message telling you to set
  it manually first, rather than risking the wrong country.
- An account that already has a UsageLocation set is never overwritten,
  either way.

## How to run it
Always launch via **Launch-AddUserLicense.bat**, never by
double-clicking or right-clicking the `.ps1` directly. The `.bat` forces
Windows PowerShell into STA mode.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in only (`User.ReadWrite.All`) — no
Exchange Online connection is made, since license assignment is a
Graph-only operation.

## Results
A per-run results CSV and PowerShell transcript are saved next to the
script after each run, plus a "Re-export last results" button as backup.

# Add Users To Group

Mass-adds **existing** users to one or more Entra ID groups. Built for the
case where a group got missed during a bulk new-hire import and you don't
want to touch each account by hand.

## What it does
- Each row has its own **Groups** cell, so different users in the same
  batch can be added to different groups — not just one shared list for
  everyone.
- Add users one at a time, paste a list, or type directly into the grid:
  - Plain UPN/email → Groups cell left blank, fill it in manually or via
    bulk-apply.
  - `UPN | Group1, Group2` (pipe-separated) → that row's own Groups cell
    gets set directly from the paste.
- **Upload CSV** matches a UPN column and, optionally, a Groups column
  (`Groups`, `Group`, `GroupNames`, `Group Names`) — if present, each
  row's groups come from the file.
- **Bulk-apply panel** — enter group(s) and click "Apply to checked
  rows" to stamp the same value onto every checked row's Groups cell at
  once, still editable afterward for the one or two people who need
  something different.
- Correctly routes M365/security groups through Microsoft Graph and only
  true mail-enabled distribution lists through Exchange Online (fixed
  misclassification bug from the main wizard's group-add logic).

## What it never does
- Never creates, disables, licenses, or otherwise modifies a user account.
- If a user or group can't be found, that row is noted in Status and the
  rest of the batch keeps going — one bad row doesn't stop the run.
- A row with no groups specified is skipped with a clear "no group(s)
  specified for this row" status, rather than silently doing nothing.

## How to run it
Always launch via **Launch-AddUsersToGroup.bat**, never by double-clicking
or right-clicking the `.ps1` directly. The `.bat` forces Windows PowerShell
into STA mode, which the sign-in UI requires — running the `.ps1` on its
own can throw a "single-threaded apartment" error.

Keep the `.bat` and `.ps1` in the same folder.

## Sign-in
Prompts for Microsoft Graph sign-in (and Exchange Online sign-in, only if
a true distribution list is targeted) using your own admin credentials.

## Results
A per-run results CSV and PowerShell transcript are saved next to the
script after each run.

#Requires -Version 5.1
<#
    CorroHealth - User Admin Toolkit
    =================================
    Consolidates three one-off, mass "do this to existing users" actions
    into a single tool and grid:

        - License tier assignment (additive only, same tier system and
          SKU mapping as UserProvisioningWizard.ps1 / the old
          AddUserLicense.ps1)
        - Group membership (adds to Entra ID groups via Graph, or to
          classic distribution lists / mail-enabled security groups via
          Exchange Online - Microsoft 365 Groups always go through Graph)
        - Invite as external guest (same B2B invite step as the main
          Wizard / the old InviteExternalGuests.ps1 - invites an
          existing HOME tenant user into the EXTERNAL tenant as a
          guest; never creates or modifies the home-tenant account)

    Job Title / Employee ID updates are a SEPARATE tool
    (UpdateUserJobInfo.ps1) - deliberately not merged in here.

    ONE ROW PER USER. Each row can touch License, Groups, Invite, any
    combination, or none (in which case it's skipped). Leave a column
    blank on a row to skip that action for that user; nothing is
    assumed or inferred beyond what's filled in.

    Apps for Enterprise (OFFICESUBSCRIPTION) is never a separate column
    any more - it's applied automatically based on tier + mode:
        Domestic F3+  -> F3 + Apps for Enterprise           (unchanged)
        Domestic E3/E5 -> tier only (SKU already bundles desktop apps)
        Global  F3+   -> F3 + Exchange Archive (50GB) + Apps for Enterprise
        Global  E3    -> E3 + Apps for Enterprise
        Global  F3    -> F3 only
        E5 is Domestic-only, exactly as before - still blocked in Global.

    Mode (Domestic / Global) is set once for the whole run via the
    toggle at the top - it controls what "F3+" means and whether E5 is
    offered, same as the original tool. It only affects rows that have
    a License Tier filled in.

    Exchange Online is only connected if at least one row in the batch
    has a Group filled in - a run that's only touching licenses or
    invites never prompts for an Exchange sign-in.

    TWO-TENANT RUN: License and Group actions happen under the HOME
    tenant connection established at launch. Invite actions happen
    under a SEPARATE connection to the EXTERNAL tenant. Rather than
    switching tenant context per row, Run processes the whole batch in
    two phases - all License/Group work first (home tenant), then, only
    if at least one checked row has Invite checked, the tool switches
    to the external tenant, sends every queued invite, then switches
    back to the home tenant before the run finishes. This mirrors how
    the main Wizard sequences the same two tenants, and avoids
    re-authenticating or flipping context row-by-row.

    This tool NEVER creates, disables, or renames the HOME tenant user
    account, and NEVER touches Job Title, Employee ID, Preferred Data
    Location, or passwords - only License, Group membership, and
    external invite, as above. If a user can't be found, or an
    individual action fails, that's noted in Status and the rest of the
    batch keeps going.

    Companion to UserProvisioningWizard.ps1 / ResetUserPasswords.ps1 /
    UpdateUserJobInfo.ps1 - same look and feel, same Corro brand
    palette, same Graph/Exchange sign-in pattern.
#>

# ============================================================
#  STA self-guard
# ============================================================
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne [System.Threading.ApartmentState]::STA) {
    $scriptPath = $MyInvocation.MyCommand.Path
    if (-not $scriptPath) { $scriptPath = $PSCommandPath }
    if (-not $scriptPath) { $scriptPath = $MyInvocation.MyCommand.Definition }

    if ($scriptPath -and (Test-Path $scriptPath)) {
        Start-Process -FilePath "powershell.exe" `
            -ArgumentList @("-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", "`"$scriptPath`"")
        exit
    } else {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "This tool must run in STA mode, but it was started in MTA and could not relaunch itself automatically.`n`nPlease launch it using Launch-UserAdminToolkit.bat instead.",
            "Please use the .bat launcher", "OK", "Warning") | Out-Null
        exit
    }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ============================================================
#  Corro brand palette + theme helpers
# ============================================================
$corroPurple    = [System.Drawing.Color]::FromArgb(0x51, 0x2e, 0x6e)
$corroSecondary = [System.Drawing.Color]::FromArgb(0x5e, 0x17, 0x4d)
$corroAccent    = [System.Drawing.Color]::FromArgb(0xe7, 0xb5, 0x24)
$themeBg        = [System.Drawing.Color]::White
$themePanel     = [System.Drawing.Color]::FromArgb(240, 240, 240)
$themeControl   = [System.Drawing.Color]::White
$themeText      = [System.Drawing.Color]::FromArgb(30, 30, 30)
$themeTextMuted = [System.Drawing.Color]::FromArgb(130, 130, 130)
$themeHeaderTxt = [System.Drawing.Color]::FromArgb(0x50, 0x2e, 0x6d)
$themeRowAlt    = [System.Drawing.Color]::FromArgb(246, 243, 249)
$themeGrey      = [System.Drawing.Color]::FromArgb(225, 222, 230)

function Set-DarkButton {
    param($Button, [switch]$Accent)
    $Button.FlatStyle = "Flat"
    if ($Accent) { $Button.ForeColor = $corroPurple; $Button.BackColor = $corroAccent }
    else { $Button.ForeColor = $corroPurple; $Button.BackColor = [System.Drawing.Color]::FromArgb(248, 246, 250) }
    $Button.FlatAppearance.BorderColor = $corroSecondary
    $Button.FlatAppearance.BorderSize = 1
    $Button.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(230, 222, 240)
}
function Set-DarkForm { param($FormObj) $FormObj.BackColor = $themeBg; $FormObj.ForeColor = $themeText }

# ============================================================
#  Tier resolution - identical mapping to the main wizard
# ============================================================
function Resolve-LicenseTier {
    param([string]$Value)
    switch (($Value + "").Trim().ToUpper()) {
        "F3"    { return "F3" }
        "2GB"   { return "F3" }
        "2 GB"  { return "F3" }
        "F3+"   { return "F3+" }
        "50GB"  { return "F3+" }
        "50 GB" { return "F3+" }
        "E3"    { return "E3" }
        "E5"    { return "E5" }
        default { return $null }
    }
}

# ============================================================
#  Connect to Graph up front (License + Group are both at least partly
#  Graph operations, under the HOME tenant). Exchange Online is
#  connected lazily, only at Run time, only if the batch needs it.
# ============================================================
Write-Host "Connecting to Microsoft Graph (home tenant)..." -ForegroundColor Cyan
try {
    Connect-MgGraph -NoWelcome -Scopes "User.ReadWrite.All", "Group.ReadWrite.All" -ErrorAction Stop
    $homeTenantId = (Get-MgContext).TenantId
} catch {
    [System.Windows.Forms.MessageBox]::Show("Could not connect to Microsoft Graph:`n`n$($_.Exception.Message)", "Graph sign-in failed", "OK", "Error") | Out-Null
    exit
}

# ============================================================
#  External tenant target for guest invites - same tenant + redirect
#  URL the main wizard / old InviteExternalGuests.ps1 uses. Invitations
#  are created in this SEPARATE tenant, never in the home tenant above.
# ============================================================
$externalTenantId          = "10096675-b04b-4d53-88e6-9c640623b9ea"
$externalInviteRedirectUrl = "https://myapplications.microsoft.com/"

function Ensure-HomeTenantContext {
    $current = (Get-MgContext).TenantId
    if ($current -eq $homeTenantId) { return $true }
    Write-Host "Switching Graph context back to the home tenant..." -ForegroundColor Cyan
    try {
        Connect-MgGraph -TenantId $homeTenantId -Scopes "User.ReadWrite.All", "Group.ReadWrite.All" -NoWelcome -ErrorAction Stop
        return $true
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not switch back to the home tenant:`n`n$($_.Exception.Message)`n`nLicense/Group actions on any further rows will fail until this succeeds.", "Home tenant reconnect failed", "OK", "Error") | Out-Null
        return $false
    }
}

function Ensure-ExternalTenantContext {
    $current = (Get-MgContext).TenantId
    if ($current -eq $externalTenantId) { return $true }
    Write-Host "Switching Graph context to the external tenant for invites..." -ForegroundColor Cyan
    try {
        Connect-MgGraph -TenantId $externalTenantId -Scopes "User.Invite.All", "User.ReadWrite.All" -NoWelcome -ErrorAction Stop
        $actualTenantId = (Get-MgContext).TenantId
        if ($actualTenantId -ne $externalTenantId) {
            throw "Connected, but the active Graph context is tenant '$actualTenantId', not the expected external tenant '$externalTenantId'. This usually means a cached sign-in session was reused instead of switching tenants. Try closing this tool and any other open PowerShell/Graph session, then relaunch."
        }
        return $true
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not connect to the external tenant:`n`n$($_.Exception.Message)", "External tenant sign-in failed", "OK", "Error") | Out-Null
        return $false
    }
}

function Get-LicenseSkus {
    return @{
        F3      = Get-MgSubscribedSku | Where-Object { $_.SkuPartNumber -eq "SPE_F1" }
        E3      = Get-MgSubscribedSku | Where-Object { $_.SkuPartNumber -eq "SPE_E3" }
        E5      = Get-MgSubscribedSku | Where-Object { $_.SkuPartNumber -eq "SPE_E5" }
        Archive = Get-MgSubscribedSku | Where-Object { $_.SkuPartNumber -eq "EXCHANGEARCHIVE_ADDON" }
        Apps    = Get-MgSubscribedSku | Where-Object { $_.SkuPartNumber -eq "OFFICESUBSCRIPTION" }
    }
}
$skus = Get-LicenseSkus
$missingSkus = @()
foreach ($key in @("F3","E3","E5","Archive","Apps")) { if (-not $skus[$key]) { $missingSkus += $key } }
if ($missingSkus.Count -gt 0) {
    [System.Windows.Forms.MessageBox]::Show(
        "Heads up: the following SKUs weren't found in this tenant's subscriptions:`n`n$($missingSkus -join ', ')`n`nAny tier that needs one of these will fail for individual users at run time (noted in Status), but the tool will still work for the tiers that are available.",
        "Some SKUs not found", "OK", "Warning") | Out-Null
}

$script:exchangeConnected = $false
function Ensure-ExchangeConnected {
    if ($script:exchangeConnected) { return $true }
    Write-Host "Connecting to Exchange Online..." -ForegroundColor Cyan
    try {
        Connect-ExchangeOnline -ShowBanner:$false -ErrorAction Stop
        $script:exchangeConnected = $true
        return $true
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not connect to Exchange Online:`n`n$($_.Exception.Message)`n`nGroup rows that need a classic distribution list / mail-enabled security group will fail until this succeeds. Entra ID groups and Microsoft 365 Groups still work without it.", "Exchange sign-in failed", "OK", "Error") | Out-Null
        return $false
    }
}

$scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$sessionTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$transcriptPath = Join-Path $scriptDir "UserAdminToolkit_$sessionTimestamp.txt"
Start-Transcript -Path $transcriptPath | Out-Null

# ============================================================
#  Main form + brand header
# ============================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "CorroHealth - User Admin Toolkit"
$form.Size = New-Object System.Drawing.Size(1040, 700)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = New-Object System.Drawing.Size(860, 560)
Set-DarkForm $form

$brandBar = New-Object System.Windows.Forms.Panel
$brandBar.Dock = "Top"; $brandBar.Height = 44; $brandBar.BackColor = $corroPurple

$logoB64 = "iVBORw0KGgoAAAANSUhEUgAAACIAAAAeCAYAAABJ/8wUAAAKMklEQVR4nK1XfZRVVRXf+5z77r3vY750BPygBksNZiQVrDBzGNOWkWXgeq9cajCgKIiNGqt0Yd15pIIlmWLmjNaklth9EGWIJup7RJbWgIozIJgaaYoCM8x7736ej90fwygGflV3rbPWXWd/nN/Z5+yzfxvgf/iy5PKRfwSApQMDdde/uHN0kcjeX89xiL2fL/wvMaDjOJjP5/UNfX/++B5ptQ8p3jok+FgRassI4iFbyK0pKVd/1a7cP23atCjruryQy6n/HxACdDqHQSx++tFFFbCuCe36tM9T4GkbRKCA+xFg1QcsV4FVqpszQsztvuTsp94LzIcG4pLLc5hT39/4QBdlGuYORRz8kIKYkus0mL1cYegNeaMhiM6UkZoIgYBEEAYZimd0Lzj34WzW5YXCgWA+FBDXdXkul1PLNv3mGqqtvWGwCqDAesJiqfn5iZM2769LRMaclRvaq3uryyiUNdwPyoen7Uk3X/aVF53OTszn83p/feODgnDIYTnMqds3rzzaU/J7IpKQIP6nM+qPOrNt3LgwS8TfLJXe2hgiKIDT7pzds/YlH/WDYJi1bwxUfgCIM7Zk3QMuLxveaZYTZTnR2xFy3Sx3KcuJaHiuNJUBAGiK59m1aVvFolIrYGbbuHGhQ0WjgKjWt7XJkQGAkHX7zJ+3T3vMIlgGiKCE/PK8xSvGFwo55TgOAwDIZrM8m3X5Bz8aAiQgvO3ZX21iDYdN3Lsr/OWiyed8wykWjXxbmzxoFPct5jWdPOqfOyvbEtqoNaPgqp7F37i51Ska6/Nv2xlExLbuOHtRwq473rInXTq27luDiECPbnNmWbW1Xx0q41VfOvaqlxGB7nv+vkM10VGgNBoM/0hE2FkqvSv2ffcAEWDn15bc18eMxCnCL08AABi1pcQAAM4//8aLIFJnsddfv2wsYuTUN4rsm4ObWhGBiLZbGsTidKNxjlTyQkQgAICq1glNOqGlAk3wBiJS89Rd9F6BdBwHCQgZY4OIDJSkNABAoQCyt7c3IaW6XivjXKbMWGmiQa8qFQe7ftj8GAmk93hDoWLI6kecNmgrYggxMzgwhNFEhP2lw97zePP5PCEgEVEjkQbOWXWfhFYUt5hakxQikMxUR+5FRM9IMA5IjQAAiKgA2S7GGZdajAEYfj+yzf17EfgrzGCkNH0eEd8vGsxxHLziF48eqYmatRTAOfbtE1Ows9wICI1aK85Gjer0APgbnAMQqY+95QXZVq00aYITi1Q0CgUAxLxGYH/QQqDm7OwbNz1yTL6tTc7t7UocgIIItzQ3G/l8Xu+pVDrQSmVk5ItMnf3wyAp+RU3k3DQBCBgiEiLbBkCgQZ8wkq4MzA2RL5AZ/JjKtu0nutmsJiLM2MmusOyHaBqZAPCX9z75ZG335EtE1nV5a7FojAxAhEIuF8+8c81ZEWEHEAHnuPonC8/bns06JgCQEOLLAIy4wfcwAAAE+6k40qC1On7T69d+BACgXo8uBVW5O1VrMk8FcxCRbn3oVrN9/PR/oDYWmaYBguOn+qz4sas3/fXkQi73jndk7fbt5uyVGzoC5Ks0MhNENFCXrlk4nNLN6krnzkOE0tNJazStxBoEANj22pzxsdy12UjVGV6lZv7kcbf/FABgzbbrbjMyqcsGy8wDajjpvAkztzt9rplvycXX9z6wXNU0LCjHHKo+xQLtUqStv4FQofKiI5UXtVKsx0MYQ8IPK/Ukp9++YPpjl99yi7W8oyO6YN4tS1SIV8tKRdSlrSnMIWDHHn7X86TNXiNBFCk5h4gYEWGCapf5Q3Fg2kY6ll4XAMDUXYdpp+gYiyZ/5XLw46uY0oNmTY0JdfVfkPUNi8LaQ76vMvWXYqZmPGMMEghP1lq8dRjEWmt5R0d08dVdJwuNVxABJCy26q67F27EIrUabbhe9u2YOYslRY8f14CIG86ZcvTSBwAAVm25+Ts8bS6txibEUeLW2S2zOlzX5Y8ePci6J18iljz9l6bdzLxgr+Cnl6Xx0SBULBnGvh3L/mSsVnWdu66AmNcznR777nx7ONu564igLJ/QnmyCKCyPrqs5vqHhtVdxpL68Aq79xksP9Fm1yaaBwdTWxmM+e1Kh1K8Xn75Yrnjux2shk/5iNUyAlNYt81q+fgUBwOVr11rLp02LRhKl5+WX7bWcozt2bIyICgAg67r8zf5+XJ/PywU3rfzEwJ7yb6QXj+exAkvHX/9F95W/BsdhOJxpWY5YUM/smPc1MNX9gc6AV00tPeO4667p6p2bGFv7ueRu4T9MydQULzIhUuY6U9csvGziGZv3pSprLZXY+lJJQ2cnQSdg69QSW7+vBiEAzFq2qj2q+j9Qvmw0pAabomt+9qP5S7NZl2ez8HbRcynLc7hSPfHCpQ8aGWtaxU9SHKXPnTbh2tUuuRw2QqacClZoM/1FTyYgCLkvMbmCWLLntMzhG9vGjQsPeNDWPDXmnwPlL0QV/2LliVMxFIB+KEwprrz7prk/mZB1zC2FfHz+jOtWvAWEyGEAedq447oxvtq9SRn2GD9OeVFknjWj5eo/OUXH6Jzaqbr7V323qnGhtGtrQkrCUEVApK0XQpXYFjH7XxQDyYqfwjBu0l7UjJIOxUgBegFwP3jG1uE373Jmb5g0aW5i48ZuMWvWTd3h3vjid9QJ183yXK6gSi98d4pi8jGBdjKQyQrp1IUzPrHgdw45LI95ffuzDx3nMfatIcHOic3MqMisAw9t8CgFItLAKj4wPwAo+6AHBiARis2mkHecVt/Q097eFg6v5fLfP/LaHcITF4ly9UCqWCw6RltbXq7bfsPZiks3BjvpC0sRpPJ8c90Nuf3I7219T415k3RrVfBTKzpx3F6ZqPd9CakoVkYYv2or/VxSUml+y6FPtrS0xCN2HYvvPW7PzvIdwhNTIYwB4uCvB62cRXKMNszLNf1LTtOmcb8wkodH2oIgMv+sIdl58YTcuoPZ4TCHAAYA+iByp2d1/SsvVeeHFX+hCmQDixWgCN1TPtM0511L+EhkVj99c5PKJLoFt8+MwIaKhyAguY5Y+h6TpR+/fPypr72bDwCA3l5K3P3MQy2VSjg9LvsXUqSbKIgBgiA0SS++p6tjCcD7sPiR1gEAYMXzP5vnaf5tZaabYpYGL2RQ8WGPgOQzEu3nfGX+HbhZTigO5cEqJz88QvrRsdqPTtBe0MLJ4OjHQJUqGEI+kmS4qPuHF/UCOAygk96XszqOw/KdeQIE6nl6dX1kidme5BeGZJ2g0odAyNLgKxOqkkNVWSBCBdyLgEUxYCAAvBCgXAW9d6hiKfV4irDrjmvPewgAYP8e5wOT5/2jQ0Rs+bbilLLE06ux8emK5EdXdaKxSpYtQ2UxL/SNUFSNSL5uCNmfkHrDYdx6/Mb2tn8MeyN0nHf2Nh+qwdpHlvl/svY+IvO3W3ccukeLdFLozO6qGBhXV1NZ9MmPDur9OJzjOGxLczMerO38Ny1LrfrtGJskAAAAAElFTkSuQmCC"
try {
    $logoBytes = [System.Convert]::FromBase64String($logoB64)
    $logoStream = New-Object System.IO.MemoryStream(,$logoBytes)
    $logoImage = [System.Drawing.Image]::FromStream($logoStream)
    $logoPic = New-Object System.Windows.Forms.PictureBox
    $logoPic.Image = $logoImage
    $logoPic.SizeMode = "AutoSize"
    $logoPic.BackColor = [System.Drawing.Color]::Transparent
    $logoPic.Location = New-Object System.Drawing.Point(12, 7)
    $brandBar.Controls.Add($logoPic)
    $labelX = 54
} catch {
    $labelX = 12
}

$brandLabel = New-Object System.Windows.Forms.Label
$brandLabel.Text = "CorroHealth  |  User Admin Toolkit"
$brandLabel.ForeColor = [System.Drawing.Color]::White
$brandLabel.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$brandLabel.AutoSize = $true; $brandLabel.Location = New-Object System.Drawing.Point($labelX, 11)
$brandBar.Controls.Add($brandLabel)

# ---- Mode toggle (Domestic / Global) - controls what F3+ means, the
#      auto Apps-for-Enterprise rule, and whether E5 is offered ----
$modePanel = New-Object System.Windows.Forms.Panel
$modePanel.Dock = "Top"; $modePanel.Height = 40; $modePanel.BackColor = $themePanel; $modePanel.Padding = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
$lblMode = New-Object System.Windows.Forms.Label
$lblMode.Text = "Mode:"; $lblMode.AutoSize = $true; $lblMode.Location = New-Object System.Drawing.Point(8, 10); $lblMode.ForeColor = $themeText
$btnModeDomestic = New-Object System.Windows.Forms.Button
$btnModeDomestic.Text = "Domestic"; $btnModeDomestic.Width = 90; $btnModeDomestic.Height = 26; $btnModeDomestic.Location = New-Object System.Drawing.Point(58, 6); $btnModeDomestic.FlatStyle = "Flat"
$btnModeGlobal = New-Object System.Windows.Forms.Button
$btnModeGlobal.Text = "Global / India"; $btnModeGlobal.Width = 110; $btnModeGlobal.Height = 26; $btnModeGlobal.Location = New-Object System.Drawing.Point(152, 6); $btnModeGlobal.FlatStyle = "Flat"
$lblTierNote = New-Object System.Windows.Forms.Label
$lblTierNote.AutoSize = $true; $lblTierNote.Location = New-Object System.Drawing.Point(272, 10); $lblTierNote.ForeColor = $themeTextMuted
$modePanel.Controls.AddRange([System.Windows.Forms.Control[]]@($lblMode, $btnModeDomestic, $btnModeGlobal, $lblTierNote))

$script:currentMode = "Domestic"
function Set-ModeButtons {
    if ($script:currentMode -eq "Domestic") {
        $btnModeDomestic.BackColor = $corroAccent; $btnModeDomestic.ForeColor = $corroPurple
        $btnModeGlobal.BackColor = $themeGrey; $btnModeGlobal.ForeColor = $themeTextMuted
        $lblTierNote.Text = "F3+ = F3 + Apps for Enterprise (bundled automatically).  E5 available."
    } else {
        $btnModeGlobal.BackColor = $corroAccent; $btnModeGlobal.ForeColor = $corroPurple
        $btnModeDomestic.BackColor = $themeGrey; $btnModeDomestic.ForeColor = $themeTextMuted
        $lblTierNote.Text = "F3+ = F3 + Exchange Archive (50GB) + Apps for Enterprise.  E3 also gets Apps.  E5 not offered."
    }
}
Set-ModeButtons

# ---- Toolbar ----
$toolbar = New-Object System.Windows.Forms.FlowLayoutPanel
$toolbar.Dock = "Top"; $toolbar.Height = 40; $toolbar.Padding = New-Object System.Windows.Forms.Padding(8, 6, 8, 6); $toolbar.BackColor = $themePanel
function New-ToolButton($text, $width) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Width = $width; $b.Height = 26; Set-DarkButton $b; return $b
}
$btnAddRow         = New-ToolButton "Add row" 80
$btnPasteList      = New-ToolButton "Paste list" 90
$btnUploadCsv      = New-ToolButton "Upload CSV" 95
$btnRemoveSelected = New-ToolButton "Remove selected" 115
$btnSelectAll      = New-ToolButton "Select all" 85
$btnExportResults  = New-ToolButton "Re-export last results" 150
$toolbar.Controls.AddRange([System.Windows.Forms.Control[]]@($btnAddRow, $btnPasteList, $btnUploadCsv, $btnRemoveSelected, $btnSelectAll, $btnExportResults))

# ---- Grid ----
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = "Fill"
$grid.AllowUserToAddRows = $false; $grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.RowHeadersVisible = $false
$grid.AutoSizeColumnsMode = "None"; $grid.RowTemplate.Height = 26; $grid.SelectionMode = "FullRowSelect"
$grid.BackgroundColor = $themeBg; $grid.GridColor = [System.Drawing.Color]::FromArgb(220, 214, 228); $grid.BorderStyle = "None"; $grid.EnableHeadersVisualStyles = $false
$grid.DefaultCellStyle.BackColor = $themeBg; $grid.DefaultCellStyle.ForeColor = $themeText
$grid.DefaultCellStyle.SelectionBackColor = $corroPurple; $grid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
$grid.AlternatingRowsDefaultCellStyle.BackColor = $themeRowAlt; $grid.AlternatingRowsDefaultCellStyle.ForeColor = $themeText
$grid.AlternatingRowsDefaultCellStyle.SelectionBackColor = $corroPurple; $grid.AlternatingRowsDefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
$grid.ColumnHeadersDefaultCellStyle.BackColor = $themePanel
$grid.ColumnHeadersDefaultCellStyle.ForeColor = $themeHeaderTxt
$grid.ColumnHeadersDefaultCellStyle.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$grid.ColumnHeadersHeight = 28
$grid.ColumnHeadersHeightSizeMode = "DisableResizing"

$colInclude = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$colInclude.Name = "Include"; $colInclude.HeaderText = ""; $colInclude.Width = 28; $colInclude.Resizable = "False"
$colUpn = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colUpn.Name = "Upn"; $colUpn.HeaderText = "User (UPN / email)"; $colUpn.Width = 190
$colTier = New-Object System.Windows.Forms.DataGridViewComboBoxColumn
$colTier.Name = "Tier"; $colTier.HeaderText = "License Tier"; $colTier.Width = 95
$colTier.Items.AddRange(@("", "F3", "F3+", "E3", "E5"))
$colTier.FlatStyle = "Flat"
$colGroups = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colGroups.Name = "Groups"; $colGroups.HeaderText = "Group(s) (comma-separated)"; $colGroups.Width = 190
$colInvite = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$colInvite.Name = "Invite"; $colInvite.HeaderText = "Invite as Guest"; $colInvite.Width = 55
$colGuestFirst = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colGuestFirst.Name = "GuestFirstName"; $colGuestFirst.HeaderText = "Guest First Name"; $colGuestFirst.Width = 110
$colGuestLast = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colGuestLast.Name = "GuestLastName"; $colGuestLast.HeaderText = "Guest Last Name"; $colGuestLast.Width = 110
$colGuestTitle = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colGuestTitle.Name = "GuestJobTitle"; $colGuestTitle.HeaderText = "Guest Job Title (optional)"; $colGuestTitle.Width = 140
$colStatus = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colStatus.Name = "Status"; $colStatus.HeaderText = "Status"; $colStatus.ReadOnly = $true; $colStatus.Width = 260
$colDelete = New-Object System.Windows.Forms.DataGridViewButtonColumn
$colDelete.Name = "Delete"; $colDelete.Text = "Remove"; $colDelete.UseColumnTextForButtonValue = $true; $colDelete.Width = 70; $colDelete.Resizable = "False"
$grid.Columns.AddRange([System.Windows.Forms.DataGridViewColumn[]]@($colInclude, $colUpn, $colTier, $colGroups, $colInvite, $colGuestFirst, $colGuestLast, $colGuestTitle, $colStatus, $colDelete))


function Sync-TierOptionsToMode {
    # E5 is Domestic-only - swap the combo's item list when the mode
    # toggle changes so the dropdown itself never offers an invalid tier.
    $colTier.Items.Clear()
    if ($script:currentMode -eq "Domestic") { $colTier.Items.AddRange(@("", "F3", "F3+", "E3", "E5")) }
    else { $colTier.Items.AddRange(@("", "F3", "F3+", "E3")) }
    # Any row already set to E5 while switching into Global gets flagged,
    # rather than silently changed, so nothing is overwritten unasked.
    if ($script:currentMode -eq "Global") {
        foreach ($row in $grid.Rows) {
            if ("$($row.Cells['Tier'].Value)" -eq "E5") { $row.Cells["Status"].Value = "E5 not valid in Global mode - fix before running" }
        }
    }
}
$btnModeDomestic.Add_Click({ $script:currentMode = "Domestic"; Set-ModeButtons; Sync-TierOptionsToMode })
$btnModeGlobal.Add_Click({ $script:currentMode = "Global"; Set-ModeButtons; Sync-TierOptionsToMode })

$grid.Add_CellClick({
    param($sender, $e)
    if ($e.RowIndex -lt 0) { return }
    if ($grid.Columns[$e.ColumnIndex].Name -eq "Delete") { $grid.Rows.RemoveAt($e.RowIndex); Update-QueueCount }
})

# ---- Add/merge a row. If the UPN is already queued, fill in only the
#      blank fields on that existing row rather than creating a
#      duplicate or overwriting something already entered. ----
function Add-UserRow {
    param(
        [string]$Upn, [string]$Tier = "", [string]$Groups = "",
        [Nullable[bool]]$Invite = $null,
        [string]$GuestFirstName = "", [string]$GuestLastName = "", [string]$GuestJobTitle = ""
    )
    $Upn = "$Upn".Trim()
    if (-not $Upn) { return }
    $tierResolved = if ($Tier) { Resolve-LicenseTier $Tier } else { $null }
    $Groups = "$Groups".Trim()
    $GuestFirstName = "$GuestFirstName".Trim(); $GuestLastName = "$GuestLastName".Trim(); $GuestJobTitle = "$GuestJobTitle".Trim()

    foreach ($row in $grid.Rows) {
        if ("$($row.Cells['Upn'].Value)".Trim() -eq $Upn) {
            if ($tierResolved -and -not "$($row.Cells['Tier'].Value)".Trim()) { $row.Cells["Tier"].Value = $tierResolved }
            if ($Groups -and -not "$($row.Cells['Groups'].Value)".Trim()) { $row.Cells["Groups"].Value = $Groups }
            if ($Invite -eq $true) { $row.Cells["Invite"].Value = $true }
            if ($GuestFirstName -and -not "$($row.Cells['GuestFirstName'].Value)".Trim()) { $row.Cells["GuestFirstName"].Value = $GuestFirstName }
            if ($GuestLastName -and -not "$($row.Cells['GuestLastName'].Value)".Trim()) { $row.Cells["GuestLastName"].Value = $GuestLastName }
            if ($GuestJobTitle -and -not "$($row.Cells['GuestJobTitle'].Value)".Trim()) { $row.Cells["GuestJobTitle"].Value = $GuestJobTitle }
            return
        }
    }
    $i = $grid.Rows.Add()
    $grid.Rows[$i].Cells["Include"].Value = $true
    $grid.Rows[$i].Cells["Upn"].Value = $Upn
    if ($tierResolved) { $grid.Rows[$i].Cells["Tier"].Value = $tierResolved }
    if ($Groups) { $grid.Rows[$i].Cells["Groups"].Value = $Groups }
    if ($Invite -eq $true) { $grid.Rows[$i].Cells["Invite"].Value = $true }
    if ($GuestFirstName) { $grid.Rows[$i].Cells["GuestFirstName"].Value = $GuestFirstName }
    if ($GuestLastName) { $grid.Rows[$i].Cells["GuestLastName"].Value = $GuestLastName }
    if ($GuestJobTitle) { $grid.Rows[$i].Cells["GuestJobTitle"].Value = $GuestJobTitle }
}

# ---- Bulk-apply panel (stamps a tier and/or job title and/or group(s)
#      onto every checked row - still editable per-row afterward) ----
$bulkPanel = New-Object System.Windows.Forms.Panel
$bulkPanel.Dock = "Bottom"; $bulkPanel.Height = 92; $bulkPanel.Padding = New-Object System.Windows.Forms.Padding(8); $bulkPanel.BackColor = $themePanel
$lblBulk = New-Object System.Windows.Forms.Label
$lblBulk.Text = "Apply to every checked row (leave a field blank to skip it):"
$lblBulk.AutoSize = $true; $lblBulk.Location = New-Object System.Drawing.Point(8, 6); $lblBulk.ForeColor = $themeText

$lblBulkTierSub = New-Object System.Windows.Forms.Label
$lblBulkTierSub.Text = "Tier:"; $lblBulkTierSub.AutoSize = $true; $lblBulkTierSub.Location = New-Object System.Drawing.Point(8, 32); $lblBulkTierSub.ForeColor = $themeText
$cmbBulkTier = New-Object System.Windows.Forms.ComboBox
$cmbBulkTier.Location = New-Object System.Drawing.Point(44, 29); $cmbBulkTier.Width = 90; $cmbBulkTier.DropDownStyle = "DropDownList"
$cmbBulkTier.Items.AddRange(@("(leave as-is)", "F3", "F3+", "E3", "E5")); $cmbBulkTier.SelectedIndex = 0

$lblBulkGroupsSub = New-Object System.Windows.Forms.Label
$lblBulkGroupsSub.Text = "Group(s):"; $lblBulkGroupsSub.AutoSize = $true; $lblBulkGroupsSub.Location = New-Object System.Drawing.Point(150, 32); $lblBulkGroupsSub.ForeColor = $themeText
$txtBulkGroups = New-Object System.Windows.Forms.TextBox
$txtBulkGroups.Location = New-Object System.Drawing.Point(214, 29); $txtBulkGroups.Width = 220
$txtBulkGroups.BackColor = $themeControl; $txtBulkGroups.ForeColor = $themeText; $txtBulkGroups.BorderStyle = "FixedSingle"

$chkBulkInvite = New-Object System.Windows.Forms.CheckBox
$chkBulkInvite.Text = "Also check 'Invite as Guest' on every checked row"
$chkBulkInvite.AutoSize = $true; $chkBulkInvite.Location = New-Object System.Drawing.Point(8, 60); $chkBulkInvite.ForeColor = $themeText

$btnApplyBulk = New-Object System.Windows.Forms.Button
$btnApplyBulk.Text = "Apply to checked rows"; $btnApplyBulk.Width = 150; $btnApplyBulk.Height = 24
$btnApplyBulk.Location = New-Object System.Drawing.Point(624, 29)
Set-DarkButton $btnApplyBulk

$bulkPanel.Controls.AddRange([System.Windows.Forms.Control[]]@(
    $lblBulk, $lblBulkTierSub, $cmbBulkTier, $lblBulkGroupsSub, $txtBulkGroups, $chkBulkInvite, $btnApplyBulk))
$bulkPanel.Add_Resize({ $btnApplyBulk.Location = New-Object System.Drawing.Point(($bulkPanel.Width - 158), 29) })

$btnApplyBulk.Add_Click({
    $t = $cmbBulkTier.SelectedItem
    $g = $txtBulkGroups.Text.Trim()
    $markInvite = $chkBulkInvite.Checked
    if ($t -eq "(leave as-is)" -and -not $g -and -not $markInvite) {
        [System.Windows.Forms.MessageBox]::Show("Fill in at least a tier, group(s), or check 'Invite as Guest' to apply first.", "Nothing to apply", "OK", "Warning") | Out-Null
        return
    }
    if ($t -eq "E5" -and $script:currentMode -eq "Global") {
        [System.Windows.Forms.MessageBox]::Show("E5 isn't offered in Global mode. Switch to Domestic first if these are Domestic users.", "E5 not valid here", "OK", "Warning") | Out-Null
        return
    }
    $applied = 0
    foreach ($row in $grid.Rows) {
        if ($row.Cells["Include"].Value -eq $true) {
            if ($t -ne "(leave as-is)") { $row.Cells["Tier"].Value = $t }
            if ($g) { $row.Cells["Groups"].Value = $g }
            if ($markInvite) { $row.Cells["Invite"].Value = $true }
            $applied++
        }
    }
    [System.Windows.Forms.MessageBox]::Show("Applied to $applied checked row(s). Still editable per-row afterward for anyone who needs something different.", "Bulk apply complete", "OK", "Information") | Out-Null
})

# ---- Action bar ----
$actionBar = New-Object System.Windows.Forms.Panel
$actionBar.Dock = "Bottom"; $actionBar.Height = 50; $actionBar.Padding = New-Object System.Windows.Forms.Padding(8); $actionBar.BackColor = $themePanel
$lblCount = New-Object System.Windows.Forms.Label
$lblCount.AutoSize = $true; $lblCount.Text = "0 users queued"; $lblCount.Location = New-Object System.Drawing.Point(8, 8); $lblCount.ForeColor = $themeText
$lblProgress = New-Object System.Windows.Forms.Label
$lblProgress.AutoSize = $true; $lblProgress.Text = ""; $lblProgress.Location = New-Object System.Drawing.Point(8, 28); $lblProgress.ForeColor = $corroPurple
$btnRun = New-Object System.Windows.Forms.Button
$btnRun.Text = "Run"; $btnRun.Width = 150; $btnRun.Height = 32; $btnRun.Anchor = "Right"
Set-DarkButton $btnRun -Accent
$actionBar.Controls.AddRange([System.Windows.Forms.Control[]]@($lblCount, $lblProgress, $btnRun))
$actionBar.Add_Resize({ $btnRun.Location = New-Object System.Drawing.Point(($actionBar.Width - 165), 9) })

$form.Controls.Add($grid)
$form.Controls.Add($bulkPanel)
$form.Controls.Add($actionBar)
$form.Controls.Add($toolbar)
$form.Controls.Add($modePanel)
$form.Controls.Add($brandBar)

function Update-QueueCount {
    $n = 0
    foreach ($row in $grid.Rows) { if ($row.Cells["Include"].Value -eq $true -and "$($row.Cells['Upn'].Value)".Trim()) { $n++ } }
    $lblCount.Text = "$n user(s) queued"
}
$grid.Add_CellValueChanged({ Update-QueueCount })
$grid.Add_CurrentCellDirtyStateChanged({ if ($grid.IsCurrentCellDirty) { $grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit) } })

# ---- Toolbar button handlers ----
$btnAddRow.Add_Click({ $i = $grid.Rows.Add(); $grid.Rows[$i].Cells["Include"].Value = $true; Update-QueueCount })
$btnSelectAll.Add_Click({ foreach ($row in $grid.Rows) { $row.Cells["Include"].Value = $true }; Update-QueueCount })
$btnRemoveSelected.Add_Click({
    $toRemove = @(); foreach ($row in $grid.Rows) { if ($row.Cells["Include"].Value -eq $true) { $toRemove += $row } }
    foreach ($row in $toRemove) { $grid.Rows.Remove($row) }; Update-QueueCount
})

# ---- Paste list: UPN, Tier, Invite(Y/N), Group1, Group2, ... ----
# Split on comma but cap at 4 pieces, so everything after the 3rd comma
# (however many commas it itself contains) becomes the Groups field
# intact - no special delimiter needed for multiple groups. Guest
# First/Last/Job Title are deliberately NOT part of paste - same as the
# original Invite tool, which only ever pasted bare UPNs and left names
# for manual entry or CSV, to avoid comma ambiguity with Groups.
$btnPasteList.Add_Click({
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Paste list - UPN, Tier, Invite, Groups"; $dlg.Size = New-Object System.Drawing.Size(540, 380); $dlg.StartPosition = "CenterParent"
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Paste one user per line, as:`n  UPN, Tier, Invite(Y/N), Group1, Group2`nLeave a field blank between commas to skip it. Tier is one of`nF3, F3+, E3, E5 (or 2GB/50GB). Invite is Y/N - checking it here only`nflags the row; fill in Guest First/Last/Job Title afterward in the grid`nor via CSV if you want a nicer guest display name than the UPN.`nEverything after the 3rd comma is taken as the Groups list, so group`nnames can have commas in them too.`n`nExample:  jsmith@corrohealth.com, E3, Y, All-Coders, Remote-Staff"
    $lbl.AutoSize = $true; $lbl.Location = New-Object System.Drawing.Point(10, 10)
    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Multiline = $true; $txt.ScrollBars = "Vertical"; $txt.Location = New-Object System.Drawing.Point(10, 130); $txt.Size = New-Object System.Drawing.Size(510, 190)
    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = "Add to grid"; $btnOk.Location = New-Object System.Drawing.Point(350, 326); $btnOk.DialogResult = "OK"
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"; $btnCancel.Location = New-Object System.Drawing.Point(445, 326); $btnCancel.DialogResult = "Cancel"
    $dlg.Controls.AddRange([System.Windows.Forms.Control[]]@($lbl, $txt, $btnOk, $btnCancel))
    $dlg.AcceptButton = $btnOk; $dlg.CancelButton = $btnCancel
    Set-DarkForm $dlg; $lbl.ForeColor = $themeText
    $txt.BackColor = $themeControl; $txt.ForeColor = $themeText; $txt.BorderStyle = "FixedSingle"
    Set-DarkButton $btnOk -Accent; Set-DarkButton $btnCancel
    if ($dlg.ShowDialog() -eq "OK") {
        $lines = $txt.Text -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        $skipped = 0
        foreach ($line in $lines) {
            $parts = $line -split ",", 4
            $upn = if ($parts.Count -ge 1) { $parts[0].Trim() } else { "" }
            $tierRaw = if ($parts.Count -ge 2) { $parts[1].Trim() } else { "" }
            $inviteRaw = if ($parts.Count -ge 3) { $parts[2].Trim() } else { "" }
            $groupsRaw = if ($parts.Count -ge 4) { $parts[3].Trim() } else { "" }
            if (-not $upn) { $skipped++; continue }
            $inviteFlag = $inviteRaw -match "^(?i)(y|yes|true|1)$"
            Add-UserRow -Upn $upn -Tier $tierRaw -Groups $groupsRaw -Invite $inviteFlag
        }
        Update-QueueCount
        if ($skipped -gt 0) {
            [System.Windows.Forms.MessageBox]::Show("$skipped line(s) were skipped - each line needs at least a UPN.", "Some lines skipped", "OK", "Warning") | Out-Null
        }
    }
})

# ---- Upload CSV: accepts a UPN column plus any mix of Tier / Groups /
#      Invite / Guest First Name / Guest Last Name / Guest Job Title
#      columns - none are required. Also accepts the main Wizard's own
#      results CSV directly (FirstName/LastName/JobTitle headers map to
#      the guest fields), same as the original Invite tool did. ----
$btnUploadCsv.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*"
    $ofd.Title = "Select a CSV with a UPN column (Tier / Groups / Invite / Guest Name columns are all optional)"
    if ($ofd.ShowDialog() -ne "OK") { return }
    try {
        $rows = Import-Csv -Path $ofd.FileName -ErrorAction Stop
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not read that CSV:`n`n$($_.Exception.Message)", "Upload failed", "OK", "Error") | Out-Null
        return
    }
    if ($rows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("That CSV has no data rows.", "Nothing to import", "OK", "Information") | Out-Null
        return
    }
    $sample = $rows[0]
    $upnProp = $sample.PSObject.Properties.Name | Where-Object { $_ -in @("UserPrincipalName","UPN","Upn","Email","EmailAddress","UserEmail","User Email") } | Select-Object -First 1
    $tierProp = $sample.PSObject.Properties.Name | Where-Object { $_ -in @("LicenseTier","License Tier","License","Tier","LicenseCode","NewLicense","New License") } | Select-Object -First 1
    $groupsProp = $sample.PSObject.Properties.Name | Where-Object { $_ -in @("Groups","Group","GroupNames","Group Names") } | Select-Object -First 1
    $inviteProp = $sample.PSObject.Properties.Name | Where-Object { $_ -in @("Invite","InviteAsGuest","Invite as Guest","ExternalInvite","Invite Guest") } | Select-Object -First 1
    $guestFirstProp = $sample.PSObject.Properties.Name | Where-Object { $_ -in @("GuestFirstName","Guest First Name","FirstName","GivenName") } | Select-Object -First 1
    $guestLastProp = $sample.PSObject.Properties.Name | Where-Object { $_ -in @("GuestLastName","Guest Last Name","LastName","Surname") } | Select-Object -First 1
    $guestTitleProp = $sample.PSObject.Properties.Name | Where-Object { $_ -in @("GuestJobTitle","Guest Job Title","JobTitle","Designation","Title") } | Select-Object -First 1
    if (-not $upnProp) {
        [System.Windows.Forms.MessageBox]::Show("Couldn't find a UPN/Email column in that CSV.`n`nColumns found: $($sample.PSObject.Properties.Name -join ', ')", "Column not found", "OK", "Error") | Out-Null
        return
    }
    $added = 0
    foreach ($r in $rows) {
        $upn = "$($r.$upnProp)".Trim()
        $tier = if ($tierProp) { "$($r.$tierProp)".Trim() } else { "" }
        $groupsVal = if ($groupsProp) { "$($r.$groupsProp)".Trim() } else { "" }
        $inviteVal = if ($inviteProp) { "$($r.$inviteProp)".Trim() -match "^(?i)(y|yes|true|1)$" } else { $null }
        $gf = if ($guestFirstProp) { "$($r.$guestFirstProp)".Trim() } else { "" }
        $gl = if ($guestLastProp) { "$($r.$guestLastProp)".Trim() } else { "" }
        $gt = if ($guestTitleProp) { "$($r.$guestTitleProp)".Trim() } else { "" }
        if ($upn) { Add-UserRow -Upn $upn -Tier $tier -Groups $groupsVal -Invite $inviteVal -GuestFirstName $gf -GuestLastName $gl -GuestJobTitle $gt; $added++ }
    }
    Update-QueueCount
    $colsUsed = @($upnProp, $tierProp, $groupsProp, $inviteProp, $guestFirstProp, $guestLastProp, $guestTitleProp) | Where-Object { $_ }
    [System.Windows.Forms.MessageBox]::Show("Added/updated $added user(s) from the '$($colsUsed -join "', '")' column(s).", "CSV loaded", "OK", "Information") | Out-Null
})

# ============================================================
#  Run: for every checked, non-blank row, do whichever of License /
#  Groups / Invite that row has filled in. License and Groups run
#  first under the HOME tenant (Phase 1); Invite runs second under the
#  EXTERNAL tenant (Phase 2), only if at least one row needs it - see
#  header comment for why this is two phases instead of per-row.
# ============================================================
$btnRun.Add_Click({
    $runTimestamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
    $modeAtRun = $script:currentMode

    $rowsToProcess = @()
    foreach ($row in $grid.Rows) {
        $upn = "$($row.Cells['Upn'].Value)".Trim()
        if (-not ($row.Cells["Include"].Value -eq $true -and $upn)) { continue }
        $tier = "$($row.Cells['Tier'].Value)".Trim()
        $groupNames = @("$($row.Cells['Groups'].Value)" -split "," | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique)
        $invite = ($row.Cells["Invite"].Value -eq $true)
        $guestFirst = "$($row.Cells['GuestFirstName'].Value)".Trim()
        $guestLast = "$($row.Cells['GuestLastName'].Value)".Trim()
        $guestTitle = "$($row.Cells['GuestJobTitle'].Value)".Trim()
        if (-not $tier -and $groupNames.Count -eq 0 -and -not $invite) { continue }
        $rowsToProcess += @{
            Row = $row; Upn = $upn; Tier = $tier; Groups = $groupNames
            Invite = $invite; GuestFirstName = $guestFirst; GuestLastName = $guestLast; GuestJobTitle = $guestTitle
            Notes = @()
        }
    }
    if ($rowsToProcess.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No checked users with a UPN and at least one of a License Tier, Group, or Invite as Guest to process.", "Nothing to run", "OK", "Warning") | Out-Null
        return
    }
    if (($rowsToProcess | Where-Object { $_.Tier -eq "E5" }).Count -gt 0 -and $modeAtRun -eq "Global") {
        [System.Windows.Forms.MessageBox]::Show("One or more checked rows are set to E5, which isn't offered in Global mode. Fix those rows or switch to Domestic mode before running.", "E5 not valid in Global mode", "OK", "Warning") | Out-Null
        return
    }

    $inviteRows = @($rowsToProcess | Where-Object { $_.Invite })
    if ($inviteRows.Count -gt 0) {
        $confirm = [System.Windows.Forms.MessageBox]::Show(
            "This will invite $($inviteRows.Count) existing user(s) as B2B guests into the external tenant. No home-tenant account is created or modified by the invite itself. Continue?",
            "Confirm invites", "YesNo", "Question")
        if ($confirm -ne "Yes") { return }
    }

    # Exchange is only needed if at least one row actually has a group -
    # and even then, only classic distribution lists / mail-enabled
    # security groups use it (Entra ID groups and Microsoft 365 Groups
    # go through Graph either way).
    $anyGroups = ($rowsToProcess | Where-Object { $_.Groups.Count -gt 0 }).Count -gt 0
    if ($anyGroups) {
        if (-not (Ensure-ExchangeConnected)) {
            $proceed = [System.Windows.Forms.MessageBox]::Show("Continue running License/Invite actions and Entra ID / Microsoft 365 group adds, skipping only the distribution-list/mail-enabled-security-group rows?", "Exchange not connected", "YesNo", "Warning")
            if ($proceed -ne "Yes") { return }
        }
    }

    $btnRun.Enabled = $false; $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    # Defensive: a prior run's Phase 2 should already have switched back,
    # but confirm we're on the home tenant before touching License/Groups.
    [void](Ensure-HomeTenantContext)

    # Resolve every DISTINCT group name once, up front, across the whole
    # batch - not per user, and not per row, even though different rows
    # can ask for different groups. A group named on 30 rows still only
    # gets looked up once.
    #
    # IMPORTANT: a mail address alone doesn't mean "use Exchange". Microsoft
    # 365 Groups (the kind that back a SharePoint site's membership, or a
    # Teams team) also get a corrohealth.com email address, but Exchange's
    # Add-DistributionGroupMember explicitly refuses them. Only classic
    # distribution lists / mail-enabled security groups need the Exchange
    # cmdlet; Microsoft 365 Groups are regular Entra ID group membership and
    # go through Graph, same as a plain security group.
    $allGroupNames = @($rowsToProcess | ForEach-Object { $_.Groups } | Select-Object -Unique)
    $resolvedGroups = @{}
    foreach ($g in $allGroupNames) {
        $grp = Get-MgGroup -Filter "DisplayName eq '$g'" -Property Id, DisplayName, Mail, GroupTypes -ErrorAction SilentlyContinue
        $isUnified = $grp -and ($grp.GroupTypes -contains "Unified")
        $isExchange = ($grp -and ($grp.Mail -like "*corrohealth.com*") -and -not $isUnified)
        $resolvedGroups[$g] = [PSCustomObject]@{ Name = $g; Group = $grp; IsExchange = $isExchange }
    }

    # ============================================================
    #  PHASE 1 - HOME TENANT: License + Groups, for every row that has
    #  either filled in. Rows with ONLY Invite checked skip this phase
    #  entirely (no home-tenant lookup needed for an invite-only row).
    # ============================================================
    $processed = 0
    $phase1Rows = @($rowsToProcess | Where-Object { $_.Tier -or $_.Groups.Count -gt 0 })
    foreach ($item in $phase1Rows) {
        $processed++
        $upn = $item.Upn
        $tier = $item.Tier
        $rowGroupNames = $item.Groups
        $row = $item.Row
        $lblProgress.Text = "Processing $upn ($processed of $($phase1Rows.Count)) - License/Groups..."; [System.Windows.Forms.Application]::DoEvents()

        $notes = $item.Notes
        $user = $null
        try { $user = Get-MgUser -UserId $upn -Property Id, DisplayName, UsageLocation -ErrorAction Stop } catch { $user = $null }

        if (-not $user) {
            $notes += "User not found: $upn"
        } else {

            # ---- License ----
            if ($tier) {
                $usageLocationOk = $true
                if (-not $user.UsageLocation) {
                    if ($modeAtRun -eq "Domestic") {
                        try {
                            Update-MgUser -UserId $user.Id -UsageLocation "US" -ErrorAction Stop
                            $notes += "UsageLocation was blank - set to US"
                        } catch {
                            $usageLocationOk = $false
                            $notes += "License failed - could not set UsageLocation: $($_.Exception.Message)"
                        }
                    } else {
                        $usageLocationOk = $false
                        $notes += "License skipped - UsageLocation is blank and Global mode doesn't guess US vs. India. Set it manually, then re-run this row."
                    }
                }

                if ($usageLocationOk) {
                    try {
                        $licenseNotes = @()
                        switch ($tier) {
                            "F3"  { Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.F3.SkuId} -RemoveLicenses @() -ErrorAction Stop; $licenseNotes += "F3 added" }
                            "F3+" {
                                Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.F3.SkuId} -RemoveLicenses @() -ErrorAction Stop
                                if ($modeAtRun -eq "Global") {
                                    Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.Archive.SkuId} -RemoveLicenses @() -ErrorAction Stop
                                    Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.Apps.SkuId} -RemoveLicenses @() -ErrorAction Stop
                                    $licenseNotes += "F3 + Exchange Archive (50GB) + Apps for Enterprise added"
                                } else {
                                    Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.Apps.SkuId} -RemoveLicenses @() -ErrorAction Stop
                                    $licenseNotes += "F3 + Apps for Enterprise added"
                                }
                            }
                            "E3" {
                                Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.E3.SkuId} -RemoveLicenses @() -ErrorAction Stop
                                if ($modeAtRun -eq "Global") {
                                    Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.Apps.SkuId} -RemoveLicenses @() -ErrorAction Stop
                                    $licenseNotes += "E3 + Apps for Enterprise added"
                                } else {
                                    $licenseNotes += "E3 added"
                                }
                            }
                            "E5" { Set-MgUserLicense -UserId $upn -AddLicenses @{SkuId=$skus.E5.SkuId} -RemoveLicenses @() -ErrorAction Stop; $licenseNotes += "E5 added" }
                            default { $licenseNotes += "Unrecognized tier: '$tier'" }
                        }
                        $notes += ("License: " + ($licenseNotes -join "; "))
                    } catch {
                        $notes += "License failed: $($_.Exception.Message)"
                    }
                }
            }

            # ---- Groups ----
            if ($rowGroupNames.Count -gt 0) {
                foreach ($gName in $rowGroupNames) {
                    $rg = $resolvedGroups[$gName]
                    if (-not $rg.Group) { $notes += "Group not found: $($rg.Name)"; continue }
                    if ($rg.IsExchange) {
                        if (-not $script:exchangeConnected) { $notes += "Skipped $($rg.Name) (Exchange) - not connected"; continue }
                        try {
                            Add-DistributionGroupMember -Identity $rg.Group.DisplayName -Member $upn -BypassSecurityGroupManagerCheck -ErrorAction Stop
                            $notes += "Added to $($rg.Name) (Exchange)"
                        } catch {
                            if ($_.Exception.Message -match "(?i)already a member") { $notes += "Already in $($rg.Name) (Exchange)" }
                            else { $notes += "Failed adding to $($rg.Name): $($_.Exception.Message)" }
                        }
                    } else {
                        try {
                            New-MgGroupMember -GroupId $rg.Group.Id -DirectoryObjectId $user.Id -ErrorAction Stop
                            $notes += "Added to $($rg.Name) (Entra ID)"
                        } catch {
                            if ($_.Exception.Message -match "(?i)already exist") { $notes += "Already in $($rg.Name) (Entra ID)" }
                            else { $notes += "Failed adding to $($rg.Name): $($_.Exception.Message)" }
                        }
                    }
                }
            }
        }

        $item.Notes = $notes
    }

    # ============================================================
    #  PHASE 2 - EXTERNAL TENANT: Invite as Guest, for every row that
    #  has it checked. Only switches tenant context if at least one
    #  row actually needs it, and switches back to home afterward -
    #  one switch each way per run, not per row.
    # ============================================================
    if ($inviteRows.Count -gt 0) {
        if (Ensure-ExternalTenantContext) {
            $processed = 0
            foreach ($item in $inviteRows) {
                $processed++
                $upn = $item.Upn
                $fn = $item.GuestFirstName
                $ln = $item.GuestLastName
                $jt = $item.GuestJobTitle
                $fullName = if ($fn -or $ln) { "$fn $ln".Trim() } else { $upn }
                $lblProgress.Text = "Inviting $upn ($processed of $($inviteRows.Count))..."; [System.Windows.Forms.Application]::DoEvents()

                $notes = $item.Notes
                try {
                    $inv = New-MgInvitation `
                        -InvitedUserEmailAddress $upn `
                        -InvitedUserDisplayName $fullName `
                        -SendInvitationMessage:$false `
                        -InviteRedirectUrl $externalInviteRedirectUrl `
                        -ErrorAction Stop
                    $notes += "External invite sent"

                    if ($fn -or $ln -or $jt) {
                        $patchParams = @{}
                        if ($fn) { $patchParams["GivenName"] = $fn }
                        if ($ln) { $patchParams["Surname"] = $ln }
                        if ($jt) { $patchParams["JobTitle"] = $jt }
                        try {
                            Update-MgUser -UserId $inv.InvitedUser.Id @patchParams -ErrorAction Stop
                            $notes += "External guest profile set"
                        } catch {
                            $notes += "External guest profile update failed: $($_.Exception.Message)"
                        }
                    }
                } catch {
                    $notes += "External invite failed: $($_.Exception.Message)"
                }
                $item.Notes = $notes
            }
        } else {
            foreach ($item in $inviteRows) {
                $item.Notes += "External invite skipped - could not connect to the external tenant"
            }
        }
        # Always switch back to home before finishing, regardless of
        # whether Phase 2 succeeded, so the next run starts correctly.
        [void](Ensure-HomeTenantContext)
    }

    # ============================================================
    #  Finalize: write Status to the grid and build the results CSV for
    #  every processed row (across both phases).
    # ============================================================
    $results = New-Object System.Collections.ArrayList
    foreach ($item in $rowsToProcess) {
        $statusText = ($item.Notes -join " | ")
        $item.Row.Cells["Status"].Value = $statusText
        [void]$results.Add([PSCustomObject]@{
            UserPrincipalName = $item.Upn
            Tier              = $item.Tier
            GroupsRequested   = ($item.Groups -join ", ")
            InviteRequested   = $item.Invite
            GuestFirstName    = $item.GuestFirstName
            GuestLastName     = $item.GuestLastName
            GuestJobTitle     = $item.GuestJobTitle
            Mode              = $modeAtRun
            Status            = $statusText
        })
    }

    $lblProgress.Text = "Done - $($rowsToProcess.Count) user(s) processed."

    $resultsPath = Join-Path $scriptDir "UserAdminToolkit_Results_$runTimestamp.csv"
    try {
        $results | Export-Csv -Path $resultsPath -NoTypeInformation -ErrorAction Stop
        $exportNote = "Results saved to:`n$resultsPath"
    } catch {
        $exportNote = "Could not save results file: $($_.Exception.Message)"
    }
    $script:lastResults = $results
    $script:lastResultsPath = $resultsPath

    $failedCount = ($results | Where-Object { $_.Status -match "(?i)failed|not found" }).Count
    [System.Windows.Forms.MessageBox]::Show(
        "Run finished.`n`nUsers processed: $($rowsToProcess.Count)`n`nRows with at least one failure/not-found: $failedCount`n`nSee the Status column for per-user, per-action detail.`n`n$exportNote",
        "Run complete", "OK", "Information") | Out-Null

    $form.Cursor = [System.Windows.Forms.Cursors]::Default; $btnRun.Enabled = $true
})

$btnExportResults.Add_Click({
    if (-not $script:lastResults -or $script:lastResults.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No run has completed yet in this session, so there's nothing to export.", "Nothing to export", "OK", "Information") | Out-Null
        return
    }
    $reExportPath = Join-Path $scriptDir "UserAdminToolkit_Results_$(Get-Date -Format 'yyyyMMdd_HHmmss_fff')_reexport.csv"
    try {
        $script:lastResults | Export-Csv -Path $reExportPath -NoTypeInformation -ErrorAction Stop
        [System.Windows.Forms.MessageBox]::Show("Last run's results (from $script:lastResultsPath) re-exported to:`n`n$reExportPath", "Re-export complete", "OK", "Information") | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not re-export results:`n`n$($_.Exception.Message)", "Re-export failed", "OK", "Error") | Out-Null
    }
})

$form.Add_FormClosing({ try { Stop-Transcript | Out-Null } catch {} })
[System.Windows.Forms.Application]::Run($form)
